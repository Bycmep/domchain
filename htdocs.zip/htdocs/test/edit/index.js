"use strict";

import { Page } from "../../lib/page.js";
import { Editable } from "../../lib/editable2.js";

export class Main {

    static ini() {
        Page.body.clear().parse(`div<style:"width:500px;height:250px;display:inline-block;padding:0.5em;">#text`);
        new Editable(Page.gete("text"), { onExit: console.info });
    }

}
