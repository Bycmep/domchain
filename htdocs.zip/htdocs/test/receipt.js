const pricelist = [
    { name: 'Administration', type: 'static', rate: 18 },
    { name: 'Bather', type: 'per_minute', rate: 0.3, min: 15, max: 90, increment: 5,
        estimate: [ 15, 30, 45, 60, 75 ] },
    { name: 'Groomer assistant', type: 'per_minute', rate: 0.35, min: 15, max: 90, increment: 5,
        estimate: [ 15, 30, 45, 60, 75 ] },
    { name: 'Groomer', type: 'per_minute', rate: 0.4, min: 15, max: 90, increment: 5,
        estimate: [ 15, 30, 45, 60, 75 ] },
    { name: 'Clean feet', type: 'checkbox', rate: 20 },
    { name: 'Clean face', type: 'checkbox', rate: 15 },
    { name: 'Flee shampoo', type: 'select', options: [
        { name: 'small', rate: 10 },        
        { name: 'medium', rate: 15 },       
        { name: 'large', rate: 20 }        
    ] },
    { name: 'Medicated shampoo', type: 'select', options: [
        { name: 'small', rate: 10 },        
        { name: 'medium', rate: 15 },       
        { name: 'large', rate: 20 }        
    ] },
    { name: 'Mats', type: 'per_minute', rate: 0.75, min: 0, max: 60, increment: 4 },
    { name: 'Deshedding', type: 'per_minute', rate: 0.75, min: 0, max: 60, increment: 4 },
    { name: 'Hair dye', type: 'select', options: [
        { name: 'small', rate: 15 },        
        { name: 'medium', rate: 20 },       
        { name: 'large', rate: 25 }        
    ] },
    { name: 'Nail polish', type: 'select', options: [
        { name: 'easy', rate: 15 },        
        { name: 'hard', rate: 25 }        
    ] },

];

