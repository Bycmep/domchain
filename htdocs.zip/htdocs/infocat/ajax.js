"use strict";

export class Ajax {
    constructor (url) {
        this.url = url;
    }

    get (input, onready) {
        let request = new XMLHttpRequest();
        request.onreadystatechange = _ => {
            this.onreadystatechange(request, onready);
        };
        let s = "";
        for (const i in input) {
            if (s) s += "&";
            s += `${i}=${input[i]}`;
        }
        request.open("GET", `${this.url}?${s}`, true);
        request.send();
    }

    post (cmd, input, onready) {
        let request = new XMLHttpRequest();
        request.onreadystatechange = _ => {
            this.onreadystatechange(request, onready) };
        request.open("POST", this.url, true);
        request.setRequestHeader("Content-type", "application/json");
        input.cmd = cmd;
        request.send(JSON.stringify(input));
    }

    onreadystatechange (request, onready) {
        if (request.readyState == 4 && request.status == 200) {
            let data;
            try {
                data = JSON.parse(request.responseText);
            } catch (e) {
                const t = document.createElement("div");
                t.innerHTML = request.responseText;
                console.log(t.innerText);
                t.remove();
                return;
            }
            if (data.err) {
                console.log(data.log.replaceAll('^', '\n'));
                return;
            } 
            onready(data);
        }
    }
}