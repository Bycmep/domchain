<?php
header('Content-Type: application/json; charset=utf-8');

$servername = 'localhost';
$username = 'infocat';
$password = 'infoC@T2@24';
$dbname = 'test';
$out = [];
$db = NULL;
date_default_timezone_set('America/Los_Angeles');
$time = date('Y/m/d H:i:s');
$table = [ 'folder' => 'Folders', 'suite' => 'Suites' ];

ob_start();

try {
    $db = new mysqli($servername, $username, $password, $dbname);
    $out['err'] = FALSE;

    if (sizeof($_GET) > 0) {

        switch($_GET['cmd']) {
            case 'ini':
                if ($db->query('SHOW TABLES LIKE "Folders"')->num_rows == 0) {
                    echo 'Folders table does not exist, creating...^';
                    $db->query('CREATE TABLE Folders (
                        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                        name VARCHAR(64) NOT NULL,
                        parent INT UNSIGNED,
                        num INT UNSIGNED NOT NULL)');
                }
                if ($db->query('SHOW TABLES LIKE "Suites"')->num_rows == 0) {
                    echo 'Suites table does not exist, creating...^';
                    $db->query('CREATE TABLE Suites (
                        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                        name VARCHAR(64) NOT NULL,
                        parent INT UNSIGNED,
                        num INT UNSIGNED NOT NULL)');
                }
                if ($db->query('SHOW TABLES LIKE "Cases"')->num_rows == 0) {
                    echo 'Cases table does not exist, creating...^';
                    $db->query('CREATE TABLE Cases (
                        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                        suite INT UNSIGNED,
                        num INT UNSIGNED NOT NULL,
                        name TINYTEXT,
                        instruct MEDIUMTEXT,
                        result MEDIUMTEXT)');
                }
                if ($db->query('SHOW TABLES LIKE "Runs"')->num_rows == 0) {
                    echo 'Runs table does not exist, creating...^';
                    $db->query('CREATE TABLE Runs (
                        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                        parent INT UNSIGNED,
                        time CHAR(19),
                        name TINYTEXT,
                        description MEDIUMTEXT,
                        status INT UNSIGNED)');
                }
                if ($db->query('SHOW TABLES LIKE "RSuites"')->num_rows == 0) {
                    echo 'RSuites table does not exist, creating...^';
                    $db->query('CREATE TABLE RSuites (
                        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                        origin INT UNSIGNED,
                        name TINYTEXT,
                        parent INT UNSIGNED,
                        num INT UNSIGNED NOT NULL)');
                }
                if ($db->query('SHOW TABLES LIKE "RCases"')->num_rows == 0) {
                    echo 'RCases table does not exist, creating...^';
                    $db->query('CREATE TABLE RCases (
                        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                        parent INT UNSIGNED,
                        num INT UNSIGNED NOT NULL,
                        name TINYTEXT,
                        instruct MEDIUMTEXT,
                        result MEDIUMTEXT,
                        status INT UNSIGNED,
                        user INT UNSIGNED,
                        time CHAR(19),
                        comment MEDIUMTEXT)');
                }
                break;
            case 'suites':
                $list = []; $i = 0;
                $q = $db->query('SELECT * FROM Folders WHERE parent = '.$_GET['folder'].' ORDER BY num');
                while($f = $q->fetch_assoc()) {
                    $f['type'] = 'folder';
                    $list[$i++] = $f;
                }
                $q = $db->query('SELECT * FROM Suites WHERE parent = '.$_GET['folder'].' ORDER BY num');
                while($s = $q->fetch_assoc()) {
                    $s['type'] = 'suite';
                    $list[$i++] = $s;
                }
                $out['list'] = $list;
                break;
            case 'parent':
                $folders = $db->query('SELECT parent FROM Folders WHERE id = '.$_GET['folder']);
                $f = $folders->fetch_assoc();
                $out['folder'] = $f['parent'];
                break;
            case 'isempty':
                if ($_GET['type'] == 'folder') {
                    $q1 = $db->query('SELECT COUNT(id) AS n FROM Folders WHERE parent = '.$_GET['id']);
                    $r1 = $q1->fetch_assoc();
                    $q2 = $db->query('SELECT COUNT(id) AS n FROM Suites WHERE parent = '.$_GET['id']);
                    $r2 = $q2->fetch_assoc();
                    $out['empty'] = ($r1['n'] + $r2['n'] == 0);
                } else {
                    $q = $db->query('SELECT COUNT(id) AS n FROM Cases WHERE suite = '.$_GET['id']);
                    $r = $q->fetch_assoc();
                    $out['empty'] = ($r['n'] == 0);
                }
                break;
            case 'cases':
                $q = $db->query('SELECT * FROM Cases WHERE suite = '.$_GET['suite'].' ORDER BY num');
                $i = 0; $list = [];
                while($r = $q->fetch_assoc()) $list[$i++] = $r;
                $q = $db->query('SELECT name FROM Suites WHERE id = '.$_GET['suite']);
                $r = $q->fetch_assoc();
                $out = ['name' => $r['name'], 'list' => $list];
                break;
            case 'results':
                $list = []; $i = 0;
                $q = $db->query('SELECT * FROM Folders WHERE parent = '.$_GET['folder'].' ORDER BY num');
                while($f = $q->fetch_assoc()) {
                    $f['type'] = 'folder';
                    $list[$i++] = $f;
                }
                $q = $db->query('SELECT * FROM Runs WHERE parent = '.$_GET['folder'].' ORDER BY time DESC');
                while($r = $q->fetch_assoc()) {
                    $r['type'] = 1;
                    $list[$i++] = $r;
                }
                $out['list'] = $list;
                break;
            case 'suites.in':
                $out['list'] = searchSuitesRecursive($db, $_GET['folder'], '');
                for ($s = 0; $s < sizeof($out['list']); $s++) {
                    $q = $db->query('SELECT id, name FROM Cases WHERE suite = '.$out['list'][$s]['id'].' ORDER BY num');
                    $i = 0; $cases = [];
                    while($r = $q->fetch_assoc()) $cases[$i++] = $r;
                    $out['list'][$s]['cases'] = $cases;
                }
                break;
            case 'run.get':
                $q = $db->query('SELECT * FROM Runs WHERE id = '.$_GET['id']);
                $out = array_merge($out, $q->fetch_assoc());
                $suites = []; $s = 0;
                $q1 = $db->query('SELECT * FROM RSuites WHERE parent = '.$_GET['id'].' ORDER BY num');
                while($r1 = $q1->fetch_assoc()) {
                    $suites[$s] = $r1;
                    $cases = []; $c = 0;
                    $q2 = $db->query('SELECT * FROM RCases WHERE parent = '.$r1['id'].' ORDER BY num');
                    while($r2 = $q2->fetch_assoc()) {
                        $cases[$c++] = $r2;
                    }
                    $suites[$s++]['cases'] = $cases;
                }
                $out['suites'] = $suites;
                break;
            }
    } else {

        $in = json_decode(file_get_contents('php://input'));
        switch ($in->cmd) {
            case 'suite.new':
                $t = $table[$in->type];
                $name = quote($in->name);
                $q = $db->query('SELECT MAX(num) FROM '.$t.' WHERE parent = '.$in->folder);
                $r = $q->fetch_assoc();
                $num = (int)$r['MAX(num)'] + 1;
                $db->query('INSERT INTO '.$t.' (`name`, `parent`, `num`) VALUES ('.
                $name.','.$in->folder.','.$num.')');
                break;
            case 'suite.rename':
                $t = $table[$in->type];
                $name = quote($in->name);
                $db->query('UPDATE '.$t.' SET name = '.$name.' WHERE id = '.$in->id);
                break;
            case 'suite.swap':
                $t = $table[$in->type];
                $db->query('UPDATE '.$t.' SET num = '.$in->num2.' WHERE id = '.$in->id1);
                $db->query('UPDATE '.$t.' SET num = '.$in->num1.' WHERE id = '.$in->id2);
                break;
            case 'suite.delete':
                $t = $table[$in->type];
                $db->query('DELETE FROM '.$t.' WHERE id = '.$in->id);
                if ($in->type == 'suite') {
                    $db->query('DELETE FROM Cases WHERE suite = '.$in->id);
                }
                break;
            case 'suite.move':
                $t = $table[$in->type];
                $q = $db->query('SELECT MAX(num) FROM '.$t.' WHERE parent = '.$in->folder);
                $r = $q->fetch_assoc();
                $num = (int)$r['MAX(num)'] + 1;
                $db->query('UPDATE '.$t.' SET parent = '.$in->folder.
                    ', num = '.$num.' WHERE id = '.$in->id);
                break;
            case 'suite.clone':
                $q = $db->query('SELECT name FROM Suites WHERE id = '.$in->id);
                $r = $q->fetch_assoc();
                $name = quote($r['name']);
                $q = $db->query('SELECT MAX(num) FROM Suites WHERE parent = '.$in->folder);
                $r = $q->fetch_assoc();
                $num = (int)$r['MAX(num)'] + 1;
                $db->query('INSERT INTO Suites (name, parent, num) VALUES ('.
                $name.','.$in->folder.','.$num.')');
                $q = $db->query('SELECT MAX(id) FROM Suites');
                $r = $q->fetch_assoc();
                $id = $r['MAX(id)'];

                $from = $db->query('SELECT * FROM Cases WHERE suite = '.$in->id);
                while($f = $from->fetch_assoc()) {
                    $db->query('INSERT INTO Cases (suite, num, name, instruct, result) VALUES ('.
                        $id.','.$f['num'].','.quote($f['name']).','.
                        quote($f['instruct']).','.quote($f['result']).')');
                }
                break;
            case 'case.update':
                $value = quote($in->value);
                $db->query('UPDATE Cases SET '.$in->attr.' = '.$value.' WHERE id = '.$in->id);
                break;
            case 'case.add':
                $q = $db->query('SELECT MAX(num) FROM Cases WHERE suite = '.$in->suite);
                $r = $q->fetch_assoc();
                $num = (int)$r['MAX(num)'] + 1;
                $db->query('INSERT INTO Cases (suite, num, name, instruct, result)
                            VALUES ('.$in->suite.','.$num.',"Name","","")');
                break;
            case 'case.swap':
                $db->query('UPDATE Cases SET num = '.$in->num2.' WHERE id = '.$in->id1);
                $db->query('UPDATE Cases SET num = '.$in->num1.' WHERE id = '.$in->id2);
                break;
            case 'case.clone':
                $q = $db->query('SELECT * FROM Cases WHERE id = '.$in->id);
                $from = $q->fetch_assoc();
                $cases = $db->query('SELECT id FROM Cases WHERE suite = '.$in->suite.
                    ' AND num > '.$from['num']);
                while($case = $cases->fetch_assoc())
                    $db->query('UPDATE Cases SET num = num + 1 WHERE id = '.$case['id']);

                $db->query('INSERT INTO Cases (suite, num, name, instruct, result)
                            VALUES ('.$in->suite.','.((int)$from['num'] + 1).','.quote($from['name']).
                            ','.quote($from['instruct']).','.quote($from['result']).')');
                break;
            case 'case.delete':
                $db->query('DELETE FROM Cases WHERE id = '.$in->id);
                break;
            case 'run.new':
                $db->query('INSERT INTO Runs (parent, time, name, description)
                            VALUES ('.$in->folder.',"'.$time.'","","")');
                $q = $db->query('SELECT MAX(id) FROM Runs');
                $r = $q->fetch_assoc();
                $out['id'] = $r['MAX(id)'];
                break;
            case 'run.add.suites':
                $q = $db->query('SELECT MAX(num) FROM RSuites WHERE parent = '.$in->id);
                $r = $q->fetch_assoc();
                $suitenum = $r['MAX(num)']? (int)$r['MAX(num)'] + 1 : 1;
                foreach ($in->suites as $suite) {
                    $q = $db->query('SELECT name FROM Suites WHERE id = '.$suite);
                    $r = $q->fetch_assoc();
                    $name = $r['name'];

                    $db->query('INSERT INTO RSuites (name, origin, parent, num) VALUES ('.
                    quote($name).','.$suite.','.$in->id.','.$suitenum.')');
                    $suitenum ++;
                    $q = $db->query('SELECT MAX(id) FROM RSuites');
                    $r = $q->fetch_assoc();
                    $suiteid = $r['MAX(id)'];

                    $q = $db->query('SELECT * FROM Cases WHERE suite = '.$suite.' ORDER BY num');
                    $casenum = 1;
                    while($r = $q->fetch_assoc()) {
                        $db->query('INSERT INTO RCases (parent, num, name, instruct, result, status)
                            VALUES ('.$suiteid.','.$casenum.','.quote($r['name']).','.
                            quote($r['instruct']).','.quote($r['result']).',0)');
                        $casenum++;
                    }
                }
                break;

    

                case 'createrun':
                $q = $db->query('SELECT name FROM Suites WHERE id = '.$in->suite);
                $r = $q->fetch_assoc();
                $name = $r['name'];
                date_default_timezone_set('America/Los_Angeles');
                $time = date('Y/m/d H:i:s');
                $q = $db->query('INSERT INTO Runs (name, time) VALUES
                    ('.quote($r['name']).','.quote($time).')');
                $q = $db->query('SELECT MAX(id) FROM Runs');
                $r = $q->fetch_assoc();
                $id = $r['MAX(id)'];

                $q = $db->query('SELECT * FROM Cases WHERE suite = '.$in->suite.' ORDER BY num');
                $i = 1;
                while($from = $q->fetch_assoc()) {
                    $q2 = $db->query('INSERT INTO RunCases
                    (run, num, name, instruct, result, status, comment) VALUES ('.
                    $id.','.$i++.','.quote($name).','.quote($from['instruct']).','.
                    quote($from['result']).',0,"")');
                }
                $call = new stdClass();
                $call->run = $id;
                break;
        }
    }

    $out['log'] = strip_tags(ob_get_clean());
    echo json_encode($out); 
    $db->close();
}

catch(Exception $e) {
    $out['err'] = TRUE;
    $out['log'] = strip_tags(ob_get_clean()).$e->getMessage();
    echo json_encode($out); 
    if ($db) $db->close();
    exit(-1);
}


function searchSuitesRecursive($db, $folder, $prefix) {
    $list = []; $i = 0;
    $prefix = ($prefix) ? $prefix.' ► ' : '';
    $q = $db->query('SELECT id, name FROM Suites WHERE parent = '.$folder.' ORDER BY num');
    while($r = $q->fetch_assoc()) 
        $list[$i++] = [ 'id' => $r['id'], 'path' => $prefix.$r['name'], 'name' => $r['name'] ];

    $q = $db->query('SELECT id, name FROM Folders WHERE parent = '.$folder.' ORDER BY num');
    while($r = $q->fetch_assoc())
        $list = array_merge($list, searchSuitesRecursive($db, $r['id'], $prefix.$r['name']));
    return $list;
}

function quote($s) {
    return "'".str_replace("'","''",$s)."'";
}


?>
