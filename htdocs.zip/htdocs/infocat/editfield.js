"use strict";

export class EditField {
    constructor (element, parameters) {
        let args = { placeholder: "", maxlength: 256,
            onUpdate: _ => {}, onLeave: _ => {}, allowEmpty: true };
        if (parameters)
            for (const p in parameters) args[p] = parameters[p];

        let value = element.innerText; element.innerHTML = value;
        const placeholder = _ => {
            if (args.placeholder && !element.innerText) {
                const span = document.createElement("span");
                element.appendChild(span);
                span.classList.add("placeholder");
                span.innerText = args.placeholder;
            }
        }
        placeholder();
        element.style.cursor = "pointer";

        const onclick = (e) => {
            removeEventListener("click", onclick);
            element.contentEditable = true;
            element.style.cursor = "auto";
            element.classList.add("edited");
            if (value == "") element.innerHTML = "";
            element.focus();
            element.addEventListener("keypress", keypress);
            element.addEventListener("focusout", focusout);
        };

        const keypress = (e) => {
            if (e.key === "Enter") {
                e.preventDefault(); element.blur();
            }
        };

        const focusout = (e) => {
            removeEventListener("keypress", keypress);
            removeEventListener("focusout", focusout);
            element.addEventListener("click", onclick);
            element.contentEditable = false;
            element.style.cursor = "pointer";
            element.classList.remove("edited");
    
            let newValue = element.innerText.replace(/<[^>]*>?/gm, '').
                replace(/[\n\r]/g, '').substring(0, args.maxlength);
    
            if(!args.allowEmpty && !newValue) newValue = value;
            element.innerHTML = newValue;
            placeholder();
    
            if (newValue == value) args.onLeave();
            else {
                value = newValue;
                args.onUpdate(newValue);
            }
        };

        element.addEventListener("click", onclick);
    }
}