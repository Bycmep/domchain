"use strict";

import { DOMchain } from "./domchain.js";
import { Ajax } from "./ajax.js";
import { Editable } from "./editable.js";
import { Run } from "./inforun.js";
export const ajax = new Ajax("infocat.php");
export const Main = {
    ini: () => {
        new DOMchain();
        ajax.get({ cmd: 'ini' }, Suites.show );
    }
};

export const UI = {
    folder: 0,

    input: (place, value, length, onSuccess, onFail) => {
        const input_field = place.
            insert("input", { type: "text", placeholder: "Input a name", value: value }).element;
        input_field.focus();

        input_field.addEventListener("keypress", (e) => {
            if (e.key === "Enter") {
                e.preventDefault(); input_field.blur();
            }
        });

        input_field.addEventListener("focusout", () => {
            const name = input_field.value.replace(/<[^>]*>?/gm, '').substring(0, length);
            if (name == "" || name == value) onFail();
            else onSuccess(name);
        });
    },

    popup: (text, choice, onYes, onNo) => {
        const overlay = DOMchain.body.insert("div", { class: "overlay" });
        const popup = overlay.insert("div", { class: "popup" });
        popup.element.innerHTML = text + '<br/><br/>';
        if(choice) {
            popup.insert("div", { class: "button.fixed", innerHTML: "Yes",
                    onclick: _ => { onYes(); } }).
                append("div", { class: "button.fixed", innerHTML: "No",
                    onclick: _ => { onNo(); } });
        } else {
            popup.insert("div", { class: "button.fixed", innerHTML: "OK",
                onclick: _ => { onYes(); } });
        }
    },

    selector: (activeTab) => {
        const tabs = [ "PROJECTS", "TEST SUITES", "TEST RUNS", "TEST RESULTS", "ADMIN" ];
        const calls = [ _ => {}, _ => { Suites.show(); }, _ => { Runs.show(); }, _ => {} ];
        const table = DOMchain.body.clear().
            insert("table", { class: "tabs" });
        table.insert("tr").insert("td", { class: "logo" }).insert("img");
        let i = 0;
        for (const tab of tabs) {
            const cell = table.insert("tr").insert("td", { innerHTML: tab });
            if (i != activeTab) {
                cell.class("on");
                cell.element.addEventListener("click", calls[i]);
            }
            i++;
        }
    },
    PROJECTS: 0,
    SUITES: 1,
    RUNS: 2,
    RESULTS: 2,
    ADMIN: 3,

    pos: {
        save: _ => {
            UI.scrollX = window.scrollX;
            UI.scrollY = window.scrollY;
        },
        load: _ => {
            if (UI.scrollY !== undefined) window.scrollTo(UI.scrollX, UI.scrollY);
            UI.scrollY = undefined;
        },
        reset: _ => {
            window.scrollTo(0, 0);
        }
    }

}

const Suites = {

    show: _ => {
        ajax.get({ cmd: 'suites', folder: UI.folder }, (data) => {
            UI.selector(UI.SUITES);
            const table = DOMchain.body.
                insert("table", { class: "folders.suites" }).id('folders');

            table.insert("tr").
                insert("td", { rowSpan: 0, class: "aligner" }).
                append("td").
                append("td", { class: "buttons" }).
                append("td", { rowSpan: 0, class: "aligner" });
            if (UI.folder > 0) {
                table.insert("tr").
                    insert("td", { class: "list", onclick: Suites.goUp }).
                        insert("div", { class: "pict.icon.goUp" }).
                        append("span", { innerHTML: ".." }).up().
                    append("td");
            }

            const list = data.list;
            for (let i = 0; i < list.length; i++) {
                const line = list[i];
                const icon = (line.id == Suites.cutid && line.type == Suites.cuttype)? 'cut' :
                    (line.type == 'folder')? 'folder' :
                        (line.id == Suites.copyid)? 'copy' : 'suite';

                const buttons = table.insert("tr").
                    insert("td", { class: "list",
                        onmouseover: _ => { DOMchain.get(`b${i}`).class("show"); },
                        onmouseout: _ => { DOMchain.get(`b${i}`).declass("show"); },
                        onclick: _ => { Suites.goto(line.type, line.id); } }).
                        insert("div", { class: `pict.icon.${icon}` }).
                        append("span", { innerHTML: line.name }).up().
                    append("td", { class: "buttons" }).id(`b${i}`);

                if (i > 0 && line.type == list[i - 1].type)
                    buttons.insert("div", { class: "button.icon.up",
                        onclick: _ => { Suites.swap(line, list[i - 1]); }
                    });
                if (i < list.length - 1 && line.type == list[i + 1].type)
                    buttons.insert("div", { class: "button.icon.down",
                        onclick: _ => { Suites.swap(line, list[i + 1]); }
                    });
        
                if (line.type == 'folder') {
                    buttons.insert("div", { class: "button.icon.edit",
                    onclick: _ => { Suites.rename(i); } });
                }
                buttons.insert("div", { class: "button.icon.delete",
                        onclick: _ => { Suites.delete(line); } });
                if (line.id != Suites.cutid || line.type != Suites.cuttype)
                    buttons.insert("div", { class: "button.icon.cut",
                        onclick: _ => { Suites.cut(line); }
                    });
                if (line.type == 'suite' && line.id != Suites.copyid)
                    buttons.insert("div", { class: "button.icon.copy",
                        onclick: _ => { Suites.copy(line); }
                    });
            }

            const bottomBar = table.insert("tr").insert("td", { class: "buttonBar" });
            bottomBar.insert("div", { class: "button.icon.folderAdd",
                        onclick: _ => { Suites.new('folder'); } }).
                    append("div", { class: "button.icon.suiteAdd",
                        onclick: _ => { Suites.new('suite'); } });
            if ((Suites.cutid && Suites.cutfolder != UI.folder) || Suites.copyid)
                bottomBar.insert("div", { class: "button.icon.paste",
                    onclick: _ => { Suites.paste(); } });
            
            Suites.list = list;
        });
    },

    goUp: _ => {
        ajax.get({ cmd: 'parent', folder: UI.folder }, (data) => {
            UI.folder = data.folder;
            Suites.show();
        });
    },

    cut: (line) => {
        Suites.copyid = false;
        Suites.cutid = line.id;
        Suites.cutfolder = UI.folder;
        Suites.cuttype = line.type;
        Suites.show();
    },

    copy: (line) => {
        Suites.cutid = false;
        Suites.copyid = line.id;
        Suites.show();
    },

    paste: _ => {
        if (Suites.cutid)
            ajax.post('suite.move', { folder: UI.folder,
                id: Suites.cutid, type: Suites.cuttype }, Suites.show);
        else if (Suites.copyid)
            ajax.post('suite.clone', { folder: UI.folder, id: Suites.copyid }, Suites.show);
        Suites.cutid = false; Suites.copyid = false;
    },
    
    goto: (type, id) => {
        if (type == 'folder') {
            UI.folder = id;
            Suites.show();
        } else Cases.goto(id);
    },

    new: (type) => {
        const place = DOMchain.get("folders").getChild(-1).prepend("tr").insert("td");
        place.class("list").class("forEdit").
            insert("div", { class: "pict.icon." + type });
        UI.input(place, "", 64, (name) => { Suites.add(type, name) }, Suites.show);
    },

    add: (type, name) => {
        ajax.post('suite.new', { type: type, folder: UI.folder, name: name }, Suites.show);
    },

    rename: (num) => {
        for (let i in Suites.list) {
            DOMchain.get(`b${ i }`).remove();
        }
        const line = Suites.list[num];
        const row = DOMchain.get('folders').getChild(num + ((UI.folder > 0)? 2 : 1)).getChild(0);
        row.class('forEdit');
        row.clear().insert("div", { class: "pict.icon.folder" });
        UI.input(row, line.name, 64, (name) => {
            ajax.post('suite.rename', { type: line.type, id: line.id, name: name }, Suites.show);
        }, Suites.show);
    },

    swap: (line1, line2) => {
        ajax.post('suite.swap', { type: line1.type,
            num1: line1.num, num2: line2.num, id1: line1.id, id2: line2.id }, Suites.show);
    },

    delete: (line) => {
        ajax.get({ cmd: 'isempty', type: line.type, id: line.id },
            (data) => { Suites.warnDelete(data, line) });
    },

    warnDelete: (data, line) => {
        let text = "";
        if (line.type == 'folder') {
            text = (data.empty) ? `Delete folder <b>${ line.name }</b>?` :
                `Cannot delete folder <b>${ line.name }</b> because it's not empty.`;
        } else {
            text = (data.empty) ? `Delete test suite <b>${ line.name }</b>?` :
                `Test suite <b>${ line.name }</b> is not empty.<br/>Are you sure you want to delete it?`;
        }

        if (line.type == 'folder' && !data.empty) {
            UI.popup(text, false, Suites.show);
        } else {
            UI.popup(text, true, _ => {
                ajax.post('suite.delete', { type: line.type, id: line.id }, Suites.show); 
            }, Suites.show);
        }
    }
};

const Cases = {
    goto: (suite) => {
        Cases.suite = suite;
        UI.pos.reset();
        Cases.show();
    },

    show: _ => {
        ajax.get({ cmd: 'cases', suite: Cases.suite }, (data) => {

            UI.pos.save();
            const table = DOMchain.body.clear().
                insert("table", { class: "cases" }).id('cases');

            table.insert("tr").
                insert("td", { class: "left" }).
                    insert("div", { class: "button.icon.left",
                            onclick: _ => { Suites.show(); } }).up().
                append("td", { colSpan: 2, class: "header.pointer",
                    innerHTML: data.name, onclick: _ => { Cases.rename(); } }).id("name").
                append("td", { class: "buttons" }).
                    insert("div", { class: "button.icon.run",
                        onclick: _ => { Run.create(Cases.suite); } });
            
            const list = data.list;
            for (let i = 0; i < list.length; i++) {
                const line = list[i];
                table.insert("tr").
                    insert("td", { rowSpan: 4, class: "num",
                        innerHTML: `${i + 1}.` }).
                    append("td", { colSpan: 2, class: "name.pointer",
                            innerHTML: line.name,
                            onclick: _ => { Cases.renameCase(i); }
                        }).id(`name${i}`).
                        append("td", { rowSpan: 4, class: "buttons.blur" }).
                            insert("div", { class: "button.icon.up", onclick: _ => {
                                Cases.swap(line, list[i - 1]);
                            }}).id("up").
                            append("div", { class: "button.icon.down", onclick: _ => {
                                Cases.swap(line, list[i + 1]);
                            } }).id("down").
                            append("div", { class: "button.icon.copy",
                                onclick: _ => { Cases.copy(line); } }).
                            append("div", { class: "button.icon.delete",
                                onclick: _ => { Cases.delete(i + 1, line); } }).up(2).
                    append("tr").
                        insert("td", { class: "small", innerHTML: "INSTRUCTIONS:" }).
                        append("td", { class: "small", innerHTML: "EXPECTED RESULT:" }).up().
                    append("tr").
                        insert("td", { class: "instruct.pointer",
                            onclick: _ => { Cases.editField("instruct", i); } }).id(`instruct${i}`).
                            insert("div", { class: "toedit", innerHTML: line.instruct }).up().
                        append("td", { class: "result.pointer",
                            onclick: _ => { Cases.editField("result", i); } }).id(`result${i}`).
                            insert("div", { class: "toedit", innerHTML: line.result }).up(2).
                    append("tr").
                        insert("td", { class: "line", colSpan: 2 });
                if (i < 1) DOMchain.get("up").remove();
                if (i >= list.length - 1) DOMchain.get("down").remove();
            }

            table.insert("tr").
                insert("td").
                append("td", { colSpan: 2, class: "bottomBar" }).
                    insert("div", { class: "button.icon.plus",
                        onclick: _ => { Cases.add(); } }).
                    append("div", { class: "button.icon.book",
                        onclick: _ => { Suites.show(); } }).up().
                append("td");
            Cases.data = data;
            UI.pos.load();
        });
    },

    rename: _ => {
        const td = DOMchain.get(`name`).clear().class("edit");
        Cases.pointers(false);
        UI.input(td, Cases.data.name, 256, (name) => { 
            ajax.post('suite.rename', { type: 'suite', id: Cases.suite, name: name }, Cases.show);
        }, Cases.show );
    },

    renameCase: (line) => {
        const td = DOMchain.get(`name${ line }`).clear().class("edit");
        const pos = Cases.data.list[line];
        Cases.pointers(false);
        UI.input(td, pos.name, 256, (name) => {
            ajax.post('case.update', { id: pos.id, suite: Cases.suite,
                attr: 'name', value: name }, Cases.show);
        }, Cases.show);
    },

    editField: (attribute, line) => {
        const pos = Cases.data.list[line];
        const buttons = [
            "undo", "redo", "fontName", "fontSize", "bold", "italic", "underline",
            "strikeThrough", "removeFormat",
            "foreColor", "hiliteColor", "insertHTML", "createLink",
            "justifyLeft", "justifyCenter", "justifyRight", "justifyFull",
            "insertOrderedList", "insertUnorderedList"
        ]
        const td = DOMchain.get(`${ attribute }${ line }`);
        Cases.pointers(false);
        new Editable( td.getChild(0).element, {
            buttons: buttons, focus: true,
            onfocusout: (value) => { 
                ajax.post('case.update', { id: pos.id, suite: Cases.suite,
                    attr: attribute, value: value }, Cases.show);
            }
        });
        td.element.onclick = _ => {};
    },

    pointers: (turnOn) => {
        const attributes = [ "name", "instruct", "result" ];
        for (let i = 0; i < Cases.data.list.length; i++) {
            for (const a of attributes) {
                const e = DOMchain.get(`${a}${i}`);
                if (turnOn) e.class('pointer'); 
                else e.declass('pointer'); 
            }
        }
    },

    add: _ => {
        ajax.post('case.add', { suite: Cases.suite }, Cases.show);
    },

    swap: (line1, line2) => {
        ajax.post('case.swap', { suite: Cases.suite,
            id1: line1.id, id2: line2.id, num1: line1.num, num2: line2.num }, Cases.show);
    },

    copy: (line) => {
        ajax.post('case.clone', { suite: Cases.suite, id: line.id }, Cases.show);
    },

    delete: (num, line) => {
        UI.popup(`Are you sure you want to delete test case #${num}?`,
            true, 
            _ => { ajax.post('case.delete', { suite: Cases.suite, id: line.id }, Cases.show) },
            Cases.show);
    }

};

const Runs = {
    
    show: _ => {
        ajax.get({ cmd: 'results', folder: UI.folder }, (data) => {
            UI.selector(UI.RESULTS);
            const table = DOMchain.body.
                insert("table", { class: "folders.results" }).id('folders');

            table.insert("tr").
                insert("td", { rowSpan: 0, class: "aligner" }).
                append("td", { rowSpan: 0, class: "search" }).
                    insert("div", { class: "button.icon.search",
                        onclick: _ => { Runs.search(); } }).up().
                append("td").
                append("td", { rowSpan: 0, class: "aligner" });
            if (UI.folder > 0) {
                table.insert("tr").
                    insert("td", { class: "list", onclick: Runs.goUp }).
                        insert("div", { class: "pict.icon.goUp" }).
                        append("span", { innerHTML: ".." });
            }

            const list = data.list;
            for (let i = 0; i < list.length; i++) {
                const line = list[i];
                const icon = (line.type == 'folder')? 'folder' : `fish${line.type}`;

                table.insert("tr").
                    insert("td", { class: "list",
                        onclick: _ => { Runs.goto(line.type, line.id); } }).
                        insert("div", { class: `pict.icon.${icon}` }).
                        append("span", { innerHTML: line.name });
            }

            table.insert("tr").
                insert("td", { class: "buttonBar" }).
                    insert("div", { class: "button.icon.fishAdd",
                        onclick: _ => { Run.new(); } });
            
            Runs.list = list;
        });
    },

    goUp: _ => {
        ajax.get({ cmd: 'parent', folder: UI.folder }, (data) => {
            UI.folder = data.folder;
            Runs.show();
        });
    },

    goto: (type, id) => {
        if (type == 'folder') {
            UI.folder = id;
            Runs.show();
        } else Run.open(id);
    }

}
