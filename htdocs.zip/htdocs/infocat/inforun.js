"use strict";

import { DOMchain } from "./domchain.js";
import { EditField } from "./editfield.js";
import { Editable } from "./editable.js";
import { ajax, UI } from "./infocat.js";

export class Run {

    static new() {
        ajax.get({ cmd: 'suites.in', folder: UI.folder }, (data) => {
            const suites = data.list;
            if (suites.length == 0)
                UI.popup("Cannot create a test run: there are no test suites in this folder and its subfolders",
                    false, Runs.show);
            else {
                ajax.post('run.new', { folder: UI.folder }, (run) => {
                    run.name = "";
                    run.description = "";
                    run.suites = [];
                    Run.editor(run, suites);
                });
            }
        });
    }

    static open(id) {
        ajax.get({ cmd: 'suites.in', folder: UI.folder }, (data) => {
            const suites = data.list;
                ajax.get({ cmd: 'run.get', id: id }, (run) => {
                    Run.editor(run, suites);
                });
        });
    }

    static editor(run, availableSuites) {
        console.log(run, availableSuites);
        let suites, positions;
        const getUnaddedSuites = _ => {
            const added = [];
            for (const s of run.suites) added.push(s.origin);
            console.log(added);
            suites = [];
            for (const suite of availableSuites) {
                if (!added.includes(suite.id)) suites.push(suite);
            }
            positions = suites.length;
        }
        getUnaddedSuites();

        const table = DOMchain.body.clear().declass().class("run").
            insert("table", { class: "editor.run" }).id('run');
        const addedlist = table.insert("tr").
                insert("td", { class: "left", rowSpan: 3 }).
                    insert("div", { class: "button.icon.left",
                            onclick: _ => { Runs.show(); } }).up().
                append("td", { class: "header", innerHTML: run.name }).id("name").
                append("td", { class: "buttons", rowSpan: 3 }).
                    insert("div", { class: "button.icon.run",
                        onclick: _ => {  } }).up(2).
            append("tr").
                insert("td", { class: "description.line", innerHTML: run.description }).id("desc").up().
            append("tr").
                insert("td", { class: "small", innerHTML: "TEST SUITES:" }).up();

        new EditField(DOMchain.gete('name'), { placeholder: "Click to enter test run name" });
        new Editable(DOMchain.gete('desc'), { placeholder: "Click to enter description" });

        const added = [];
        const showExistingSuites = _ => {
            let n = 0;
            let row = addedlist;
            for (const s of run.suites) {
                row = row.append("tr");
                added.push(row);
                const cases = row.insert("td", { innerHTML: `${n + 1}.`, class: "num" }).
                    append("td", { class: "line" });

                cases.insert("table", { class: "suite" }).
                    insert("tr").
                        insert("td", { innerHTML: s.name }).
                        append("td", { class: "suitebuttons" }).
                            insert("div", { class: "button.icon.up", onclick: _ => {
                                Run.swapSuites(run.suites[n], run.suites[n - 1]);
                            }}).id("up").
                            append("div", { class: "button.icon.down", onclick: _ => {
                                Run.swapSuites(run.suites[n], run.suites[n + 1]);
                            }}).id("down").
                            append("div", { class: "button.icon.delete",
                                onclick: _ => { Run.deleteSuite(n); } });
                        
                for (const c of s.cases) {
                    cases.insert("span", { class: "small", innerHTML: c.name.toUpperCase() }).
                        append("br");
                }
                n++;
            }
        }
        showExistingSuites();


        const suitelist = table.insert("tr").
                insert("td", { rowSpan: 0 }).
                append("td");
        const bottomBar = suitelist.append("td", { rowSpan: 0 }).up().
            append("tr").
                insert("td", { class: "bottomBar" });

        const insertPlusButton = _ => {
            if (!positions) return;
            const max = 10;
            bottomBar.insert("div", { class: "button.icon.plus",
                onclick: _ => {
                    const list = suitelist.insert("div", { class: 'suitelist' }).
                        style({ height: `${ (positions > max? max : positions)*1.4}em` });
                    const suitebuttons = suitelist.insert("div");
                    for (const suite of suites) {
                        suite['active'] = false;
                        const pos = list.insert("div", { class: "suitepos", 
                            innerHTML: suite.path });
                        suite['pos'] = pos;
                        pos.set({ onclick: _ => {
                                suite.active = !suite.active;
                                if (suite.active) pos.class("marked");
                                else pos.declass("marked");
                            }
                        });
                    }
                    bottomBar.clear();
                    suitebuttons.insert("div", { class: "button.icon.star", onclick: _ => {
                            let actives = 0;
                            for (const suite of suites) if (suite.active) actives++;
                            const trigger = (actives == positions)?
                                (ste) => { if (ste.active) {
                                    ste.active = false;
                                    ste.pos.declass("marked");
                                }} :
                                (ste) => { if (!ste.active) {
                                    ste.active = true;
                                    ste.pos.class("marked");
                                }};
                            for (const suite of suites) trigger(suite);
                        } }).
                        append("div", { class: "button.icon.ok", onclick: _ => {
                            const toAdd = [];
                            for (const suite of suites) {
                                if (suite.active) toAdd.push(suite);
                            }
                            if (toAdd.length) {
                                const suitelist = [];
                                for (const suite of toAdd) {
                                    run.suites.push({ id: suite.id, name: suite.name, cases: suite.cases });
                                    suitelist.push(suite.id);
                                }
                                
                                console.log({ id: run.id, suites: suitelist });
                                ajax.post("run.add.suites", { id: run.id, suites: suitelist }, console.log);
                            }
                            suitelist.clear();
                            insertPlusButton();
                        }}).
                        append("div", { class: "button.icon.cancel", onclick: _ => {
                            suitelist.clear();
                            insertPlusButton();
                        }});
                }
            });
        };
        insertPlusButton();
    }
};
