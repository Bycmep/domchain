"use strict";

import { DOMchain } from "./domchain.js";

export class Editable {
    static supported = null;
    static active = false;

    constructor(element, _args_) {
        let args = { buttons: [
                "undo", "redo", "fontName", "fontSize", "bold", "italic", "underline",
                "strikeThrough", "subscript", "superscript", "removeFormat",
                "foreColor", "hiliteColor", "insertHTML", "createLink",
                "justifyLeft", "justifyCenter", "justifyRight", "justifyFull",
                "insertOrderedList", "insertUnorderedList", "load", "save"
            ], focus: false, onExit: _ => {}, placeholder: "" };
        if (_args_) for (const a in _args_) args[a] = _args_[a];

        Editable.checkSupport();
        const savename = "content.html";
        const body = new DOMchain(document.body);
        let textbox = new DOMchain(element).style({ cursor: "pointer" });
        let selection = false, placeholder = false;
        const showPlaceholder = () => {
            if (!args.placeholder || element.innerText) return;
            textbox.clear().insert("span", { class: "placeholder", innerHTML: args.placeholder });
            placeholder = true;
        }
        showPlaceholder();

        const onclick = _ => {
            if (Editable.active) return;
            Editable.active = true;
            element.removeEventListener("click", onclick);
            if (placeholder) { textbox.clear(); placeholder = false; }
            textbox.class("_editable_").set({ contentEditable: true }).style({ cursor: "auto" });

            const imgZoomRatio = 1.1;
            let zoomTimeout = false, zoomBar = false, overZoomBar = false, zoomImg;
            const addImageResizers = _ => {
                for (const img of element.getElementsByTagName('img')) {
                    img.onmouseover = _ => {
                        if (zoomTimeout) clearTimeout(zoomTimeout);
                        zoomTimeout = false;
    
                        if (!zoomBar) {
                            zoomBar = body.insert("div", {
                                class: "_editable_buttonBar",
                                onmouseover: _ => { overZoomBar = true; },
                                onmouseout: (event) => {
                                    overZoomBar = false;
                                    const box = img.getBoundingClientRect();
                                    if (event.clientX < box.left || event.clientX > box.right ||
                                        event.clientY < box.top || event.clientY > box.bottom ) {
                                            img.dispatchEvent(new Event("mouseout"));
                                    }
                                }
                            });
                            zoomBar.insert("div", {
                                class: "button.icon.zoomOut",
                                onclick: _ => {
                                    element.focus();
                                    if (zoomImg.clientWidth < 10) return;
                                    zoomImg.style.width = `${ zoomImg.clientWidth / imgZoomRatio }px`;
                                }
                            }).append("div", {
                                class: "button.icon.zoomIn",
                                onclick: _ => {
                                    element.focus();
                                    if (zoomImg.clientWidth > 10000) return;
                                    zoomImg.style.width = `${ zoomImg.clientWidth * imgZoomRatio }px`;
                                }
                            });
                        }
                        zoomImg = img;
                        const box = img.getBoundingClientRect();
                        zoomBar.style({
                            top: `${ (box.top < 0? 0 : box.top) + window.scrollY + 10 }px`,
                            left: `${ (box.left < 0? 0 : box.left) + window.scrollX + 10 }px`
                        });
                    };
    
                    img.onmouseout = _ => {
                        zoomTimeout = setTimeout(_ => {
                            zoomTimeout = false;
                            if (overZoomBar || !zoomBar) return;
                            zoomBar.remove();
                            zoomBar = false;
                        }, 1000);
                    };
                }
            }
            addImageResizers();

            const buttonBar = body.insert("div", { class: "_editable_buttonBar" });
            const colorBar = body.insert("div", { class: "_editable_colorBar" });
            let colorBarMode = false, stay = false, linkField = false, timeout = false;
            let pressedButton, mo, ro;

            const popup = {
                foreColor: {
                    values: [ 'hsl(0,75%,74%)', 'hsl(25,75%,68%)', 'hsl(51,75%,64%)', 'hsl(126,75%,60%)', 'hsl(161,75%,50%)',
                        'hsl(0,75%,37%)', 'hsl(25,75%,34%)', 'hsl(51,75%,32%)', 'hsl(126,75%,30%)', 'hsl(161,75%,25%)',
                        'hsl(197,75%,50%)', 'hsl(219,75%,66%)', 'hsl(274,75%,72%)', 'hsl(0,0%,67%)', 'hsl(0,0%,0%)',
                        'hsl(197,75%,25%)', 'hsl(219,75%,33%)', 'hsl(274,75%,36%)', 'hsl(0,0%,33%)', 'hsl(0,0%,100%)' ],
                    set: (button, n, value) => { button.style({ backgroundColor: value }) },
                    button: "swatch", limit: 5
                },
                fontSize: {
                    values: [ 1, 2, 3, 4, 5, 6, 7 ],
                    set: (button, n, value) => {
                        button.insert("span", {
                            innerHTML: "Aa", style: { fontSize: `${(n + 6)/15}em` }});
                        },
                    button: "button"
                },
                fontName: {
                    values: [
                        "Arial, Helvetica, sans-serif",
                        "Segoe UI, Tahoma, Geneva, Verdana, sans-serif",
                        "Times New Roman, Times, serif",
                        "Georgia, Garamond, Times, serif",
                        "Courier New, Courier, monospace"
                    ],
                    set: (button, n, value) => {
                        button.insert("span", {
                            innerHTML: "Aa", style: { fontFamily: `${value}em` }});
                    },
                    button: "button"
                }
            };
            popup['hiliteColor'] = popup['foreColor'];

            const positionColorBar = _ => {
                const box = textbox.getBox();
                const cbox = colorBar.getBox();
                const button = pressedButton.getBoundingClientRect();
                const top = button.top - cbox.height;
                let left = button.left + button.width/2 - cbox.width/2;
                if (left + cbox.width > box.right) left = box.right - cbox.width;
                if (left < box.left) left = box.left;
                colorBar.style({
                    top: `${ top + window.scrollY }px`, 
                    left: `${ left + window.scrollX }px`
                });
            };

            const setSelection = _ => {
                const s = window.getSelection();
                s.setBaseAndExtent(selection[0], selection[1],
                    selection[2], selection[3] );
            };
            const goToPos = (reset) => {
                if (!selection || reset) {
                    const lastNode = (node) => {
                        if (node.childNodes.length == 0) return node;
                        return lastNode(node.childNodes[node.childNodes.length - 1]);
                    }
                    const node = lastNode(element);
                    const char = node.length;
                    selection = [ node, char, node, char ];
                }
                setSelection();
                element.focus();
            }

            const execute = (event, b) => {
                stay = true;
                element.focus();
                if (colorBarMode) colorBar.clear();
                if (colorBarMode == b) {
                    colorBarMode = false;
                    stay = false;
                    return;
                }
                switch (b) {
                    case "foreColor":
                    case "hiliteColor":
                    case "fontSize":
                    case "fontName":
                        colorBarMode = b;
                        let n = 0;
                        const pop = popup[b];
                        for (const value of pop.values) {
                            const button = colorBar.insert("div", {
                                class: pop.button + ".icon", onclick: _ => {
                                    setSelection();
                                    document.execCommand(b, false, value);
                                    colorBar.clear();
                                    colorBarMode = false;
                                    stay = false;
                                    element.focus();
                                }
                            });
                            if (pop.limit && (n + 1)%pop.limit == 0) colorBar.insert("br");
                            pop.set(button, n++, value);
                        }
                        pressedButton = event.target;
                        positionColorBar();
                        stay = false;
                        return;
                    case "undo":
                    case "redo":
                    case "bold":
                    case "italic":
                    case "underline":
                    case "strikeThrough":
                    case "subscript":
                    case "superscript":
                    case "removeFormat":
                    case "justifyLeft":
                    case "justifyCenter":
                    case "justifyRight":
                    case "justifyFull":
                    case "insertOrderedList":
                    case "insertUnorderedList":
                        document.execCommand(b);
                        break;
                    case "createLink":
                        colorBarMode = b;
                        colorBar.insert("input", { type: "text",
                            placeholder: "Input link here, empty to unlink",
                            onfocus: _ => { stay = true; },
                            onblur: _ => {
                                setSelection();
                                element.focus();
                                stay = false;
                            },
                            onkeypress: (e) => {
                                if (e.key !== "Enter") return;
                                e.preventDefault();
                                const value = e.target.value;
                                const v = value.toLowerCase();
                                if (!v.startsWith('http://') && !v.startsWith('https://') && v != "") return;
                                setSelection();
                                if (value == "") document.execCommand("unlink", false);
                                else document.execCommand(b, false, value);
                                colorBar.clear();
                                colorBarMode = false;
                                stay = false;
                                element.focus();
                            }
                        }).focus();
                        pressedButton = event.target;
                        positionColorBar();
                        return;
                    case "insertHTML":
                        let inputImg = document.createElement('input');
                        inputImg.type = 'file'; inputImg.accept = '.png,.jpg,.jpeg';
                        inputImg.onchange = _ => {
                            const reader = new FileReader();
                            reader.addEventListener('load', _ => {
                                element.focus();
                                const s = `<img name='_img_' src='${ reader.result }'/>`;
                                document.execCommand("insertHTML", false, s);
                                addImageResizers();
                                stay = false;
                            });
                            reader.readAsDataURL(inputImg.files[0]);
                            inputImg.remove();
                        };
                        inputImg.click();
                        return;
                    case "load":
                        const inputHtml = document.createElement('input');
                        inputHtml.type = 'file'; inputHtml.accept = '.html';
                        inputHtml.onchange = _ => {
                            const reader = new FileReader();
                            reader.addEventListener('load', (event) => {
                                const doc = event.target.result;
                                element.innerHTML =
                                    doc.substring(doc.indexOf("<body>" + 6), doc.indexOf("</body>"));
                                addImageResizers();
                                goToPos(true);
                                stay = false;
                            });
                            reader.readAsText(inputHtml.files[0]);
                            inputHtml.remove();
                        };
                        inputHtml.click();
                        return;
                    case "save":
                        const doc = "<!DOCTYPE html><html><body>" + element.innerHTML + "</body></html>";
                        const e = document.createElement("a");
                        e.href = window.URL.createObjectURL(new Blob([ doc ], {type: "text/plain"}));
                        e.download = savename;
                        e.click();
                        e.remove();
                        return;
                }
                colorBarMode = false;
                stay = false;
                return;
            }
    
            for (const b of args.buttons) {
                if (Editable.supported[b]) buttonBar.insert("div", {
                        class: "button.icon." + b,
                        onclick: (event) => { execute(event, b) }
                    });
            }
            
            ro = new ResizeObserver(_ => {
                const box = textbox.getBox();
                buttonBar.style({
                    width: `${ box.width }px`,
                    top: `${ box.top + box.height + window.scrollY }px`,
                    left: `${ box.left + window.scrollX }px`
                });
                if (colorBarMode) positionColorBar();
            });
            ro.observe(element);
            mo = new MutationObserver(_ => {
                if (zoomBar && !element.contains(zoomImg)) {
                    zoomBar.remove();
                    zoomBar = false;
                    if(zoomTimeout) clearTimeout(zoomTimeout);
                }
            });
            mo.observe(element, { childList: true, subtree: true });
            goToPos(false);
    
            element.addEventListener("focusout", _ => {
                const s = window.getSelection();
                selection = [ s.anchorNode, s.anchorOffset, s.focusNode, s.focusOffset ];
    
                timeout = setTimeout(_ => {
                    if (stay) return;
                    ro.disconnect();
                    mo.disconnect();
                    textbox.declass('_editable_').set({ contentEditable: false });
                    colorBar.remove();
                    buttonBar.remove();
                    const clone = element.cloneNode(true);
                    element.parentNode.replaceChild(clone, element);
                    element = clone;
                    textbox = new DOMchain(element).style({ cursor: "pointer" });
                    element.addEventListener("click", onclick);
                    Editable.active = false;
                    const value = element.innerHTML;
                    showPlaceholder();
                    args.onExit(value);
                }, 300);
            });

            element.addEventListener("focusin", _ => {
                if (timeout) {
                    clearTimeout(timeout);
                    timeout = false;
                }
            });
        }

        element.addEventListener("click", onclick);
        if(args.focus) element.click();
    }

    static checkSupport() {
        if (Editable.supported) return;
        const cmd = [
            { cmd: "removeFormat" },
            { cmd: "bold" },
            { cmd: "createLink", argument: "google.com" },
            { cmd: "fontName" },
            { cmd: "fontSize", argument: 3 },
            { cmd: "foreColor" },
            { cmd: "hiliteColor" },
            { cmd: "insertHTML", argument: "<img/>" },
            { cmd: "insertOrderedList" },
            { cmd: "insertUnorderedList" },
            { cmd: "italic" },
            { cmd: "justifyCenter" },
            { cmd: "justifyFull" },
            { cmd: "justifyLeft" },
            { cmd: "justifyRight" },
            { cmd: "undo" },
            { cmd: "redo" },
            { cmd: "strikeThrough" },
            { cmd: "subscript" },
            { cmd: "superscript" },
            { cmd: "underline" },
        ];
        Editable.supported = { load: true, save: true };
        const textbox = new DOMchain(document.body).insert("div", { contentEditable: true });

        for (let command of cmd) {
            const span = textbox.insert("span", { innerHTML: "test" }).element;
            const range = document.createRange();
            range.setStartBefore(span);
            range.setEndAfter(span);
            window.getSelection().addRange(range);
            textbox.focus();
            Editable.supported[command.cmd] = document.execCommand(command.cmd, true, command.argument);
            textbox.clear();
        }
        textbox.remove();
    }
}
