"use strict";

export class DOMchain {
    static ids = [];
    static body;

    constructor(element, parent) {
        if (element) {
            this.element = element;
            this.parent = parent;
        } else {
            this.element = document.body;
            this.parent = null;
            DOMchain.body = this;
        }
    }

    insert(type, parameters) {
        let e = document.createElement(type);
        const created = new DOMchain(e, this);
        if (this.child == undefined) this.child = [ created ];
        else this.child.push(created);
        this.element.appendChild(e);
        return created.set(parameters);
    }

    append(type, parameters) {
        let e = document.createElement(type);
        const created = new DOMchain(e, this.parent);
        const index = this.parent.child.indexOf(this);
        if (index + 1 == this.parent.child.length) {
            this.parent.element.appendChild(e);
        }
        else {
            this.parent.element.insertBefore(e, this.parent.child[index + 1].element);
        }
        this.parent.child.splice(index + 1, 0, created);
        return created.set(parameters);
    }

    prepend(type, parameters) {
        let e = document.createElement(type);
        const created = new DOMchain(e, this.parent);
        const index = this.parent.child.indexOf(this);
        this.parent.child.splice(index, 0, created);
        this.parent.element.insertBefore(e, this.element);
        return created.set(parameters);
    }

    set(parameters) {
        if (parameters == undefined) return this;
        const e = this.element;
        for (const property in parameters) {
            const value = parameters[property];
            if (property == 'class') {
                const classes = value.split('.');
                for (const c of classes)
                    e.classList.add(c);
            } else if (property == 'style') {
                for (const i in value) {
                    const setting = value[i];
                    e.style[i] = setting;
                }
            } else e[property] = value;
        }
        return this;
    }

    style(parameters) {
        const e = this.element;
        for (const property in parameters) {
            const value = parameters[property];
            e.style[property] = value;
        }
        return this;
    }

    getChild(num) {
        if (num < 0) return this.child[this.child.length + num];
        return this.child[num];
    }

    geteChild(num) {
        return this.getChild(num).element;
    }

    up(n) {
        let r = this;
        if (n == undefined) n = 1;
        for (let i = 0; i < n; i++) r = r.parent;
        return r;
    }

    class(classname) {
        this.element.classList.add(classname);
        return this;
    }

    declass(classname) {
        if (!classname) this.element.removeAttribute('class');
        else this.element.classList.remove(classname);
        return this;
    }

    id(id) {
        DOMchain.ids[id] = this;
        return this;
    }

    static get(id) {
        return DOMchain.ids[id];
    }

    static gete(id) {
        return DOMchain.ids[id].element;
    }

    getBox() {
        return this.element.getBoundingClientRect();
    }

    html() {
        return this.element.innerHTML;
    }

    focus() {
        this.element.focus();
        return this;
    }

    blur() {
        this.element.blur();
        return this;
    }

    find(element) {
        if (this.element == element) return this;
        if (this.child)
            for (const child of this.child) {
                const found = child.find(element);
                if (found) return(found);
            }
        return false;
    }

    clear() {
        this.element.innerHTML = "";
        this.child = undefined;
        return this;
    }

    remove() {
        this.element.remove();
        if (this.parent != undefined) {
            const index = this.parent.child.indexOf(this);
            if(index != -1) {
                this.parent.child.splice(index, 1);
            }
        }
    }
}
