"use strict";

import { Page } from "../lib/page.js";
import { Pdf } from "../lib/pdf.js";
import { Envelope } from "./envelope.js";
import { Ruler } from "./ruler.js";

export class Main {
    static DPI = 300;
    static MARGIN = 200;

    static ini() {
        Page.body.parse(`
            div.screen{
                div.panel#panel{
                    div.subpanel{
                        button<tooltip:"Click to load a PDF file">("Open PDF")#openpdf
                        div.controls.noshow#controls {
                            p.fname.small#filename
                            p.small#pagesize
                            button<tooltip:"Go to the previous page">("◄")#prev
                            span("Page")
                            number.pagenum<tooltip:"Enter page number to go to">#goto
                            span#ofpages
                            button<tooltip:"Go to the next page">("►")#next
                        }
                    }
                    div.noshow2#tools {
                        div.subpanel {
                            p{ span("Envelope:") select#envelope_list }
                            p.small.envdesc#envelope_desc
                            div.noshow#envcontrols{
                                table.tap#tap{
                                    tr{ td{ radio<name:tap>#tap1 } td td{ radio<name:tap>#tap2 }}
                                    tr{ td td{ radio<name:tap>#tap3 } td }
                                    tr{ td{ radio<name:tap,checked:true>#tap4 } td td{ radio<name:tap>#tap5 }}
                                }
                                p{ checkbox<id:cfold>#customfold
                                    label<for:cfold>("Custom fold") br
                                    div.foldcontrols.noshow#customfields {
                                        span number<min:0,step:0.01>#cfold0 span('"')
                                        number<min:0,step:0.01>#cfold1 span('"') 
                                        number<min:0,step:0.01>#cfold2 span('"') }
                                }
                                div.noshow#envcontrols2{        
                                    p{ checkbox<id:remit>#remittance
                                        label<for:remit>("Address at the bottom") }
                                    p{ checkbox<id:tolerance>#tolerance
                                        label<for:tolerance>("IMB tolerance") }
                                    p{ button("Scan Barcode")#scanBarcode }
                                }
                                table{ tr{ td{ span#pages } td{ button(-)#pg_minus } td{ button(+)#pg_plus }}}
                            }
                        }
                        div.subpanel {
                            p{ checkbox<id:ruler>#ruler
                                label<for:ruler>("Ruler") br
                                div.noshow#rulercontrols{
                                    radio<name:ruler,checked:true>#ruler_p span.label("Page")
                                    radio<name:ruler>#ruler_e span.label("Envelope") br
                                    checkbox#rulersnap span.label("Snap to fractions") }}
                            p{ checkbox#omr span.label("OMR codes")}
                            p{ table{ tr{ td{ button("Check margins")#margins }
                                td{ radio<name:margin,checked:true>#margins316 span.label('3/16"')
                                    radio<name:margin>#margins18 span.label('1/8"') }}}}
                        }
                        div.subpanel {
                            table{ tr{ td.zoom#zoom td{ button(-)#zoomMinus button(+)#zoomPlus }}}
                            p.ppi.small{ span("Screen resolution:")
                                text<maxlength:3>#ppi span("PPI") }
                        }
                    }
                }
                div#page {
                    div.pageMv#pageMv {
                        canvas#canvas
                        svg#pageSvg { g.foldlines#foldlines g#omr g#margin }
                        svg#pageback
                        svg.rulers.noshow#rulers
                    }
                    svg.envelope#envelope {
                        g.tolerance#tolerance
                    }
                }
            }`);
        Main.pdf = new Pdf(Page.gete('canvas'), { scalable: Page.gete("page") });
        Page.gete("openpdf").onclick = _ => { Main.pdf.open(Main.showControls) };
        Page.gete("prev").onclick = _ => { Main.pdf.goto(Main.pdf.page - 1, Main.updateControls); };
        Page.gete("goto").oninput = _ => { Main.pdf.goto(parseInt(Page.gete("goto").value), Main.updateControls); };
        Page.gete("next").onclick = _ => { Main.pdf.goto(Main.pdf.page + 1, Main.updateControls); };
        Envelope.populate(Page.get("envelope_list"));
        Page.get("pages").text(`Pages: ${Envelope.pages}`);
        Page.gete("tap1").onclick = _ => { Envelope.tap(1); }
        Page.gete("tap2").onclick = _ => { Envelope.tap(2); }
        Page.gete("tap3").onclick = _ => { Envelope.tap(3); }
        Page.gete("tap4").onclick = _ => { Envelope.tap(4); }
        Page.gete("tap5").onclick = _ => { Envelope.tap(5); }
        Page.gete("remittance").onclick = _ => { Envelope.remittance(); }
        Page.gete("customfold").onclick = _ => { Envelope.switchFold(); }
        Page.gete("cfold0").onchange = _ => { Envelope.customFold(0); }
        Page.gete("cfold1").onchange = _ => { Envelope.customFold(1); }
        Page.gete("cfold2").onchange = _ => { Envelope.customFold(2); }
        Page.gete("ruler").onchange = _ => { Ruler.show(); }
        Ruler.ini();
    }

    static showControls() {
        Page.get("controls").declass("noshow");
        Page.get("tools").declass("noshow2");
        Page.get("filename").text(Main.pdf.filename).set({ tooltip: Main.pdf.filename });
        Page.get("goto").set({ min: 1, max: Main.pdf.pages });
        Page.get("ofpages").text(`of ${Main.pdf.pages}`);
        Main.updateControls();
        
        Main.updateZoomControls();
        Page.gete("zoomMinus").onclick = _ => { Main.pdf.zoom(-1); Main.updateZoomControls(); };
        Page.gete("zoomPlus").onclick = _ => { Main.pdf.zoom(1); Main.updateZoomControls(); };
        
        const ppiField = Page.gete("ppi");
        ppiField.value = Main.pdf.screenDPI;
        ppiField.onchange = _ => {
            ppiField.blur();
            Main.pdf.setScreenDPI(ppiField.value);
            ppiField.value = Main.pdf.screenDPI;
        };
    }

    static updateControls() {
        Page.get("pagesize").text(`${Main.pdf.width}" x ${Main.pdf.height}"`);
        const pageWidth = Main.pdf.width * Main.DPI + 2 * Main.MARGIN;
        const pageHeight = Main.pdf.height * Main.DPI + 2 * Main.MARGIN;
        Page.get("pageSvg").style({ width: pageWidth, height: pageHeight });
        Envelope.show();
        Page.get("prev").set({ disabled: Main.pdf.page == 1 });
        Page.get("next").set({ disabled: Main.pdf.page == Main.pdf.pages });
        Page.get("goto").set({ value: Main.pdf.page });
        Page.gete("cfold0").max = Main.pdf.height;
        Page.gete("cfold1").max = Main.pdf.height;
        Page.gete("cfold2").max = Main.pdf.height;
    }

    static updateZoomControls() {
        Page.get("zoom").text(`Zoom: ${ Math.round(Main.pdf.scale * 100) }%`);
        Page.get("zoomMinus").set({ disabled: Main.pdf.cantZoom(-1) });
        Page.get("zoomPlus").set({ disabled: Main.pdf.cantZoom(1) });
    }

}
