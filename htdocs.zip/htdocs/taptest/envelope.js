"use strict";

import { envelopes } from "./envelope.list.js";
import { Page } from "../lib/page.js";
import { Main } from "./main.js";

export class Envelope {
    static width = 0;
    static height = 0;
    static pages = 1;
    static current = 0;
    static cFold = [ 0, 0, 0 ];
    static folds = [];
    static cFoldEnabled = false;
    static bottomAddress = false;
    static tapped = 4;
    static IMBtolerance = false;

    static populate(envelopeList) {
        const list = envelopeList.element;
        envelopeList.insert("option").text(" ");
        for (const e of envelopes)
            envelopeList.insert("option").text(e.name);
        list.onchange = _ => {
            Envelope.show(list.selectedIndex);
        }
    }

    static show(num) {
        const n = (num == undefined)? Envelope.current : num;
        Envelope.current = n;
        const svg = Page.get("envelope");
        svg.clear();
        if (n) {
            const height = Main.pdf.height, width = Main.pdf.width;
            let envelope = envelopes[n - 1];
            const desc = envelope.description && envelope.specification?
                envelope.description + ' ' + envelope.specification :
                envelope.description? envelope.description :
                envelope.specification? envelope.specification : "";
            Page.get("envelope_desc").text(desc);
            if (envelope.specification) {
                let e;
                for (e of envelopes)
                    if (e.name == envelope.specification) break;
                envelope = e;
            }
            Envelope.height = envelope.height; Envelope.width = envelope.width;

            Envelope.fold(envelope);
            const inset = Envelope.getInset(Envelope.folds.length, Envelope.pages);
            if (Envelope.ymax - Envelope.ymin + 2*inset > envelope.height) {
                Page.get('tap').class('unfit');
                Page.get('envcontrols2').class('noshow');
            } else {
                Page.get('tap').declass('unfit');
                Page.get('envcontrols2').declass('noshow');
            }

            const dy = envelope.height * Main.DPI, dx = envelope.width * Main.DPI;
//            svg.style({ width: `${ dx + 2*Main.MARGIN }px`, height: `${ dy + 2*Main.MARGIN }px` });
            let path = `M${Main.MARGIN} ${Main.MARGIN} h${dx} v${dy} h-${dx}z `;
            for (const window of envelope.windows) {
                const x = window.left*Main.DPI + Main.MARGIN, y = window.top*Main.DPI + Main.MARGIN;
                const r = window.rounding*Main.DPI, rc = r*0.55;
                const dx = window.width*Main.DPI - 2*r, dy = window.height*Main.DPI - 2*r;
                path += `M${x} ${y+r} c0 ${-rc},${r-rc} ${-r},${r} ${-r} h${dx} c${rc} 0,${r} ${r-rc},${r} ${r} v${dy} c0 ${rc},${rc-r} ${r},${-r} ${r} h${-dx} c${-rc} 0,${-r} ${rc-r},${-r} ${-r}z `;
            }
            svg.insert("path", { d : path });

            Envelope.tolerance();

            const top = inset - Envelope.ymin;
            const left = inset;
            const right = envelope.width - width - inset;
            const bottom = envelope.height - Envelope.ymax - inset;

            Envelope.pos = [
                { x: left, y: top },
                { x: right, y: top },
                { x: (envelope.width - width)/2,
                    y: (envelope.height - (Envelope.ymax + Envelope.ymin))/2 },
                { x: left, y: bottom },
                { x: right, y: bottom } 
            ];

            Envelope.tap();
            Page.get("envcontrols").declass("noshow");
        } else {
            Page.get("envcontrols").class("noshow");
            Page.get("pageMv").style({ left: `0px`, top: `0px` });
            Envelope.height = Envelope.width = 0;
        }
        
    }

    static tap(n) {
        if (n) Envelope.tapped = n; else n = Envelope.tapped;
        Page.get("pageMv").style({ left: `${Envelope.pos[n - 1].x * Main.DPI + Main.MARGIN}px`,
            top: `${Envelope.pos[n - 1].y * Main.DPI + Main.MARGIN}px` });
    }

    static remittance() {
        Envelope.bottomAddress = !Envelope.bottomAddress;
        Envelope.show();
    }

    static fold(envelope) {
        const height = Main.pdf.height, width = Main.pdf.width;
        const foldlines = Page.get("foldlines"); foldlines.clear();
        const pageback = Page.get("pageback"); pageback.clear();
        const foldWidth = 0.15*Main.DPI, pageWidth = 0.15*Main.DPI;
        if (Envelope.cFoldEnabled) {
            Envelope.folds = [];
            const folds = [ 0, height ];
            for (const f of Envelope.cFold) if (f) {
                    Envelope.folds.push(f);
                    folds.push(f);
            }
            Envelope.folds.sort((a, b) => { return a - b; });
            const comparator = Envelope.bottomAddress?
                (a, b) => { return b - a; } : (a, b) => { return a - b; }
            folds.sort(comparator);
            let y = Envelope.bottomAddress? height : 0;
            let direction = 1;
            let ymin = y, ymax = y;
            for (let i = 1; i < folds.length; i++) {
                y += (folds[i] - folds[i - 1]) * direction; direction = -direction;
                if (ymin > y) ymin = y; if (ymax < y) ymax = y;
            }
            let x = folds.length*foldWidth;
            y = (y - ymin)*Main.DPI;
            pageback.style({
//                width: folds.length*foldWidth + pageWidth + 3,
//                height: (ymax - ymin)*Main.DPI + 6,
                top: ymin*Main.DPI,
                left: width*Main.DPI
            })
            for (let i = folds.length - 1; i > 0; i--) {
                let y0 = y;
                y += (folds[i] - folds[i - 1])*Main.DPI*direction; direction = -direction;
                pageback.insert("path", {
                    d: `M${x} ${y0} h${pageWidth} l-${foldWidth},${y - y0} h-${pageWidth}z`,
                    fill: direction == 1? 'white' : 'aliceblue'
                 });
                 x -= foldWidth;
            }            
            Envelope.ymin = ymin; Envelope.ymax = ymax;
        } else {
            Envelope.resetFold();
            let fold;
            for (fold = 1; fold < 5; fold++)
                if (height/fold < envelope.height) break;
            Envelope.folds = [];
            for (let f = 1; f < fold; f++) Envelope.folds[f - 1] = height*f/fold;
            if (Envelope.bottomAddress) {
                Envelope.ymax = height;
                Envelope.ymin = height - height/fold;
            } else {
                Envelope.ymin = 0;
                Envelope.ymax = height/fold;
            }
        }
        for (const y of Envelope.folds)
            foldlines.insert("path",
                { d: `M0 ${y * Main.DPI} h${width * Main.DPI}` });
    }

    static customFold(n) {
        const e = Page.gete(`cfold${n}`);
        let value = parseFloat(e.value);
        if (value < 0) value = 0; if (value > Main.pdf.height) value = Main.pdf.height;
        e.value = `${value}`;
        Envelope.cFold[n] = value;
        Envelope.show();
    }

    static resetFold() {
        for (let i = 0; i < 3; i++) {
            Page.gete(`cfold${i}`).value = "";
            Envelope.cFold[i] = 0;
        }
    }

    static switchFold() {
        const checked = Page.gete("customfold").checked;
        Envelope.cFoldEnabled = checked;
        if (checked) {
            Page.get("customfields").declass("noshow");
            for (let i in Envelope.folds) {
                const value = Math.round(Envelope.folds[i]*100)/100;
                Envelope.cFold[i] = value;
                Page.gete(`cfold${i}`).value = value;
            }
        }
        else {
            Page.get("customfields").class("noshow");
            Envelope.resetFold();
        }
        Envelope.show();
    }

    static tolerance() {

    }




    static chgPages(delta) {
        const MAX_PAGES = [ 0, 70, 15, 7, 7 ];

        if (slip) {
            inset = getInset(1, 1);
            ePagesMinus.disabled = ePagesPlus.disabled = true;
            ePagesNum.innerHTML = pages = 1;
        } else {
            pages += delta;
            if (pages < 1) pages = 1;
            if (pages > MAX_PAGES[fold]) pages = MAX_PAGES[fold];
            inset = getInset(pages, fold);
            ePagesMinus.disabled = (pages > 1) ? false : true;
            ePagesPlus.disabled = (pages == MAX_PAGES[fold]) ? true : false;
            ePagesNum.innerHTML = pages;
        }
        if (delta != 0) showE();
    }
    
    static getInset(pages, fold) {
        const k = 1/300;
        return k*(pages*fold + 4);
    }
    

}
