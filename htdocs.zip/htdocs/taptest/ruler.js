"use strict";

import { Page } from "../lib/page.js";
import { Main } from "./main.js";
import { Envelope } from "./envelope.js";

export class Ruler {
    static width = 0;
    static height = 0;
    static MARGIN = 1500;
    static RULERWIDTH = 20;
    static r = [];

    static ini() {
        const r = Page.get("rulers");
        for (let i = 0; i < 4; i++) {
            const svg = r.insert("svg");
            Ruler.r[i] = { x0: 0, x: 0, dot0: 0, dot: 0, vert: i < 2, svg: r.insert("svg") };
        }
        Ruler.diffx = r.insert("path");
        Ruler.diffy = r.insert("path");
        Ruler.box = r;
        
        for (const i in Ruler.r) {
            const r = Ruler.r[i];
            const e = r.svg.element;
            e.onmousedown = (evt) => {
                r.x0 = r.vert? evt.clientX : evt.clientY;
                r.dot0 = r.dot;
                evt.preventDefault();

                document.onmousemove = (evt) => {
                    evt.preventDefault();
                    r.x = r.vert? evt.clientX : evt.clientY;
                    r.dot = (r.x - r.x0) / Main.pdf.pxscale + r.dot0;
                    console.log(r);
                    Ruler.showLine(r);
                }

                document.onmouseup = _ => {
                    document.onmousemove = _ => {};
                    document.onmouseup = _ => {};
                }
            }
        }
    }

    static showLine(r) {
        Ruler.dx = Main.pdf.width*Main.DPI + 2*Ruler.MARGIN;
        Ruler.dy = Main.pdf.height*Main.DPI + 2*Ruler.MARGIN;
        const d = r.vert? `M${r.dot} ${-Ruler.MARGIN} v${Ruler.dy}` :
            `M${-Ruler.MARGIN} ${r.dot} h${Ruler.dx}`;
        r.path.set({ d: d });
    }

    static show() {
        Ruler.box.declass("noshow");

        for (const r of Ruler.r) this.showLine(r);
            



                /*
        Ruler.box.style({
            width: Main.pdf.width * Main.DPI + 2*Ruler.MARGIN,
            height: Main.pdf.height * Main.DPI + 2*Ruler.MARGIN,
            top: `${-Ruler.MARGIN}px`,
            left: `${-Ruler.MARGIN}px`
        })




                const width = Math.max(Envelope.width, Main.pdf.width)*Main.DPI + 2*Main.MARGIN;
            const height = Math.max(Envelope.width, Main.pdf.width)*Main.DPI + 2*Main.MARGIN;
            const edy = Envelope.current? Envelope.height : 0;
            const 




            if (Ruler.width != Main.pdf.width || Ruler.height != Main.pdf.height) {
                Ruler.dx = 2*Main.pdf.width*Main.DPI + 2*Main.MARGIN + 2*Ruler.MARGIN;
                Ruler.odx = Main.pdf.width*Main.DPI + Main.MARGIN + 2*Ruler.MARGIN;
                Ruler.dx = 2*Main.pdf.width*Main.DPI + 2*Main.MARGIN + 2*Ruler.MARGIN;
                Ruler.dy = 2*Main.pdf.height*Main.DPI + 2*Main.MARGIN + 2*Ruler.MARGIN;
                Ruler.box.style({
                    height: Ruler.dy,
                    width: Ruler.dx,
                });
                for (const r of Ruler.r) {
                    if (r.y === null) {
                        if (r.x > Ruler.maxX) r.x = Ruler.maxX;
                    } else {
                        if (r.y > Ruler.maxY) r.y = Ruler.maxY;
                    }
                    const d = (r.y === null)? `M${r.x} 0 v${Ruler.dy}` : `M0 ${r.y} h${Ruler.dy}`;
                    r.path.set({ d: d });
                }
                Ruler.width = Main.pdf.width; Ruler.height = Main.pdf.height;
            }
            Ruler.box.declass("noshow");
            Page.get("rulercontrols").declass("noshow");
        } else {
            Ruler.box.class("noshow");
            Page.get("rulercontrols").class("noshow");
        }
*/
    }
}
