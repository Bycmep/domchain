"use strict";

export const envelopes = [
    { name: "House #10", width: 9+1/2, height: 4+1/8,
        windows: [
            { left: 7/8, top: 2, width: 4+1/2, height: 1+1/2, rounding: 1/3 },
            { left: 7/8, top: 7/16, width: 3+1/4, height: 1+1/16, rounding: 1/4 }
        ],
        description: "Standard #10 envelope with a window for return address." },
    { name: "Custom #10", width: 9+1/2, height: 4+1/8,
        windows: [
            { left: 7/8, top: 2, width: 4+1/2, height: 1+1/2, rounding: 1/3 },
        ],
        description: "Standard #10 envelope with the return address printed on it." },
    { name: "House #9", width: 8+7/8, height: 3+7/8,
        windows: [
            { left: 4+3/8, top: 1+1/2, width: 4, height: 1, rounding: 1/3 },
        ],
        description: "Standard envelope for returns." },
    { name: "House 6x9", width: 9+1/2, height: 6,
        windows: [
            { left: 7/8, top: 2+3/8, width: 4+1/2, height: 1+1/2, rounding: 1/3 },
            { left: 7/8, top: 13/16, width: 3+1/4, height: 1+1/16, rounding: 1/4 }
        ],
        description: "Standard 6x9 envelope with a window for return address." },
    { name: "Custom 6x9", width: 9+1/2, height: 6,
        windows: [
            { left: 7/8, top: 2+3/8, width: 4+1/2, height: 1+1/2, rounding: 1/3 },
        ],
        description: "Standard 6x9 envelope with the return address printed on it." },
    { name: "House 9x12", width: 9, height: 12,
        windows: [
            { left: 1/2, top: 3/4, width: 4+1/4, height: 3+1/4, rounding: 1/3 },
        ],
        description: "Standard 9x12 envelope with a window for return address." },
    { name: "Custom 9x12", width: 9, height: 12,
        windows: [
            { left: 1/2, top: 2+1/2, width: 4+1/4, height: 1+1/2, rounding: 1/3 },
        ],
        description: "Standard 9x12 envelope with the return address printed on it." },
    { name: "4401", specification: "House #10" },
    { name: "4401*", width: 9+1/2, height: 4+1/8,
        windows: [
            { left: 7/8, top: 2+1/16, width: 4+1/2, height: 1+1/2, rounding: 1/3 },
            { left: 7/8, top: 1/2, width: 3+1/4, height: 1+1/16, rounding: 1/4 }
        ],
        description: "A bad batch of 4401"
    },
    { name:"4402", specification: "House #10" },
    { name:"4403", specification: "House #9" },
    { name:"4404", specification: "House #10", description: "Tax envelope." },
    { name:"4406", specification: "House 9x12" },
    { name:"4408", specification: "House 6x9" },
    { name:"4411", specification: "House 9x12", description: "TX version of 4406." },
    { name:"4412", specification: "House 6x9" },
    { name:"4413", width: 9+1/2, height: 4+1/8,
        windows: [
            { left: 3/4, top: 2, width: 4+1/2, height: 1+1/2, rounding: 1/3 },
            { left: 3/8, top: 5/16, width: 5+1/2, height: 1+3/8, rounding: 1/3 }
        ],
        description: "INFO, non-standard." },
    { name:"4414", specification: "House 9x12" },
    { name:"4415", specification: "House #10", description: "Tax envelope." },
    { name:"4416", width: 9, height: 11+1/2,
        windows: [
            { left: 3+3/4, top: 13/16+2+1/4, width: 4+1/2, height: 1+3/4, rounding: 1/3 },
            { left: 3+3/4, top: 13/16, width: 3+1/4, height: 4, rounding: 1/3 },
            { left: 9/16, top: 15/16, width: 2, height: 3/4, rounding: 1/4 }
        ],
        description: "INFO, non-standard." },
    { name:"5186", 
        width: 8+3/4, height: 11+5/16,
        windows: [
            { left: 5/8, top: 2+1/4, width: 4+1/2, height: 1, rounding: 1/3 },
        ],
        description: "FRST, non-standard." },
    { name:"5188*", width: 9+1/2, height: 4+1/8,
        windows: [
            { left: 9/16, top: 2, width: 4+1/2, height: 1+1/2, rounding: 1/4 },
        ],
        description: "GCBK, bad batch. Vendor used wrong specifications." },
    { name:"5205", width: 9+1/2, height: 4+1/8,
        windows: [
            { left: 7/8, top: 1/2, width: 4+1/4, height: 2, rounding: 1/3 },
        ],
        description: "FCBT, non-standard, TX. Permit." },
    { name:"5207", width: 9+1/2, height: 4+1/8,
        windows: [
            { left: 7/8, top: 2+7/16, width: 4+1/2, height: 1+1/8, rounding: 1/3 },
        ],
        description: "FRST, non-standard." },
    { name:"5208", width: 9+1/2, height: 4+1/8,
        windows: [
            { left: 7/8, top: 1/2, width: 4+1/4, height: 2, rounding: 1/3 },
        ],
        description: "FCBT, non-standard, TX." },
    { name:"5295", width: 9+1/2, height: 4+1/8,
        windows: [
            { left: 7/8, top: 2+1/2, width: 4+1/2, height: 1+1/8, rounding: 1/3 },
        ],
        description: "CAIG, non-standard." },
    { name:"5296", width: 9+1/2, height: 6,
        windows: [
            { left: 1+1/8, top: 2+1/4, width: 3+3/8, height: 1+1/4, rounding: 1/3 },
        ],
        description: "CAIG, non-standard." },
    { name:"5297", width: 8+9/16, height: 3+5/8,
        windows: [
            { left: 1+1/2, top: 1+5/8, width: 4, height: 1, rounding: 1/3 },
        ],
        description: "CAIG, non-standard." },
    { name:"5301", width: 9, height: 12,
        windows: [
            { left: 1, top: 2+7/8, width: 3+1/8, height: 1+3/8, rounding: 1/3 },
        ],
        description: "CAIG, non-standard." },
    { name:"5302", width: 9+1/2, height: 11+5/8,
        windows: [
            { left: 1+1/8, top: 2+1/2, width: 3, height: 1+1/4, rounding: 1/3 },
        ],
        description: "CAIG, non-standard." },
    { name:"5303", width: 9, height: 12,
        windows: [
            { left: 7/8, top: 2+5/16, width: 3, height: 1+1/4, rounding: 1/3 },
        ],
        description: "CAIG, non-standard." },
    { name:"5309", width: 9+1/2, height: 12+1/2,
        windows: [
            { left: 1+1/16, top: 1, width: 3+3/4, height: 3, rounding: 1/3 },
        ],
        description: "UFC, non-standard, TX. Permit." },
    { name:"5348", width: 9, height: 12,
        windows: [
            { left: 7/8, top: 2+1/2, width: 3+3/4, height: 1+1/4, rounding: 1/4 }
        ],
        description: "SAFE, non-standard." },
    { name:"5652", width: 9+1/2, height: 4+1/8,
        windows: [
            { left: 5/8, top: 2+1/4, width: 4+1/2, height: 1+1/4, rounding: 1/3 },
        ],
        description: "RWCU, non-standard." },
    { name:"5665", width: 9+1/2, height: 4+1/8,
        windows: [
            { left: 3/4, top: 2+3/8, width: 4+1/4, height: 1+1/4, rounding: 1/3 },
        ],
        description: "TFCU, non-standard." },
    { name:"5746", width: 9+1/2, height: 6,
        windows: [
            { left: 7/8, top: 2+5/16, width: 4+1/2, height: 1+3/4, rounding: 1/3 },
        ],
        description: "EWBB, non-standard, permit." },
    { name:"6084", width: 8+7/8, height: 3+7/8,
        windows: [
            { left: 4+7/16, top: 2+1/8, width: 4, height: 1+1/8, rounding: 1/3 },
        ],
        description: "UCCU, non-standard." },
];
