"use strict";

const date = new Date();

console.log(date.getMonth(), date.getDate());
if (date.getMonth() == 11 || (date.getMonth() == 0 && date.getDate() < 8)) { // and so this is Christmas
    const stars = [];
    for (let i = 0; i < 10; i ++) {
        stars[i] = { x: 0, y: 0, time: 0, e: document.getElementById('s' + i) };
    }
    const base_x = 200, base_z = 380;
    const colors = [ [ 240, 200, 50 ], [ 90, 140, 240 ], [ 200, 200, 240 ], [ 200, 180, 240 ], [ 240, 150, 50 ] ];
    const color = Math.floor(Math.random()*colors.length);
    let output = `<radialGradient id="grad1" cx="35%" cy="35%" r="80%" fx="35%" fy="35%"><stop offset="0%" style="stop-color:rgb(255,255,255)"/><stop offset="60%" style="stop-color:rgb(${colors[color][0]},${colors[color][1]},${colors[color][2]})" /><stop offset="100%" style="stop-color:rgb(${colors[color][0]/2},${colors[color][1]/2},${colors[color][2]/2})"/></radialGradient>`;
    output += `<radialGradient id="grad2" cx="50%" cy="50%" r="100%" fx="50%" fy="50%"><stop offset="0%" style="stop-color:rgb(255,255,255);stop-opacity:1"/><stop offset="100%" style="stop-color:rgb(255,230,0);stop-opacity:0.5"/></radialGradient>`;
    let tree = {
        height: 350,
        width: Math.random()*80 + 130,
        leg: 0,
        branch_angle: Math.random()*0.3,
        needle_length: 10 + Math.random()*5
    };
    if (tree.leg < -tree.width/2 * tree.branch_angle) tree.leg = -tree.width/2 * tree.branch_angle;
    const branch_angle = Math.asin(tree.branch_angle);
    const n_branches = 250;
    for (let i = 0; i < n_branches; i++) {
        const angle_xy = Math.PI/2 + Math.PI*i/n_branches * ((i%2 == 0) ? 1 : -1);
        const branch_color = RGB(120, 0.4, 0.05+0.3*(1 - Math.pow(angleDiff(angle_xy/Math.PI, 1.2),1/6)));
        const z1 = Math.random()*(tree.height - tree.leg) + tree.leg;
        const k = tree.branch_angle*(0.9 + Math.random()*0.2);
        const x2 = (tree.height - z1)/(k + tree.height/tree.width*2);
        const z2 = k*x2 + z1;
        const branch_sina = Math.sin(angle_xy)*0.2, branch_cosa = Math.cos(angle_xy);

        const n_needles = (tree.height - z1 + 10); // * (0.01 + Math.abs(branch_cosa));
        output += `<path stroke='${branch_color}' d='`;
        for (let j = 0; j < n_needles; j++) {
            const rand = 1 - j*j/n_needles/n_needles;
            const rand2 = Math.random()*Math.PI - Math.PI/2;
            const x = x2 * rand;
            const z = z1 + (z2 - z1)*rand;
            const k = x2/(z1 - z2)*(0.8 + Math.random()*0.4);
            const side = (Math.random() > 0.5) ? 1 : -1;
            const dx1 = tree.needle_length/Math.sqrt(1 + k*k)*((Math.random() > 0.5) ? 1 : -1);
            const dx2 = tree.needle_length*Math.cos(tree.branch_angle + rand2);

            const a = Math.random()*2*Math.PI;
            const sina = Math.sin(a), cosa = Math.cos(a);
            const dz1 = dx1*k;
            const dz2 = tree.needle_length*Math.sin(branch_angle + rand2);
            const dx = dx2*rand + dx1*(1 - rand);
            const dz = (dz2*rand + dz1*(1 - rand))*cosa;
            const dy = (dz2*rand + dz1*(1 - rand))*sina;
            output += `M${base_x + x*branch_cosa} ${base_z - z - x*branch_sina} l${dx*branch_cosa + dy*sina} ${-dz - dx*branch_sina - dy*cosa*0.2} `;
    }
    output += `'/>`;
    
    }

    const dist = (x1, y1, x2, y2) => ((x1 - x2)*(x1 - x2) + (y1 - y2)*(y1 - y2));
    let xs = [], ys = [];
    for (let i = 0; i < tree.width/6; i ++) {
        let fit, x, y, mdist=800;
        do {
            fit = true;
            y = 10 + Math.random()*(tree.height-20);
            let r = Math.random() - 1/2;
            let rs = (r > 0) ? 1 : -1;
            r = (1 - r*r*4)/2*rs;
            x = base_x + tree.width*y/tree.height*r;
            for (let j = 0; j < i; j ++) {
                if (dist(x, y, xs[j], ys[j]) < mdist) {
                    fit = false; mdist--; break;
                }
            }
        } while(!fit);
        xs[i] = x; ys[i] = y;
        output += `<circle cx="${x}" cy="${base_z - tree.height + y}" r="10" fill="url(#grad1)"/>`;
    }
    //            output += `<path stroke='none' fill='url(#grad2)' d='M200 200 l4 100 l100 4 l-100 4 l-4 100 l-4 -100 l-100 -4 l100 -4 l4 -100'/>`;


    function angleDiff(a, b) {
        while (a < 0) a += 2; while (b < 0) b += 2;
        while (a >= 2) a -= 2; while (b >= 2) b -= 2;
        let diff = Math.abs(a - b);
        if (diff > 1) return 2 - diff;
        return diff;
    }

    function RGB(h, s, l) {
        const c = (1 - Math.abs(2*l - 1))*s;
        const x = c*(1 - Math.abs(Math.floor(h/60)%2 - 1));
        const m = l - c/2;
        let r, g, b;
        if (h < 180) {
            if (h < 60) { r = c; g = x; b = 0; }
            else if (h < 120)  { r = x; g = c; b = 0; }
            else { r = 0; g = c; b = x; }
        } else {
            if (h < 240) { r = 0; g = x; b = c; }
            else if (h < 300) { r = x; g = 0; b = c; }
            else { r = c; g = 0; b = x; } 
        }
        return '#' + Math.round((r + m)*255).toString(16).padStart(2,'0') + Math.round((g + m)*255).toString(16).padStart(2,'0') + Math.round((b + m)*255).toString(16).padStart(2,'0');

    }

    function blink() {
        for (let i = 0; i < 10; i ++) {
            stars[i].time --;
            if (stars[i].time <= 0) {
                stars[i].e.innerHTML = '';
                let y = 10 + Math.random()*(tree.height-20);
                stars[i].x = base_x + tree.width*y/tree.height*(1/2 - Math.random());
                stars[i].y = base_z - tree.height + y;
                stars[i].time = Math.floor(Math.random()*20) + 20;
            } else if (stars[i].time < 20) {
                let d = Math.abs(10 - stars[i].time); if (d == 0) d = 1;
                let l1 = 50/d, l2 = 2/d;
                stars[i].e.innerHTML = `<path stroke='none' fill='url(#grad2)' d='M${stars[i].x - l2/2} ${stars[i].y - l2/2} l${l2} -${l1} l${l2} ${l1} l${l1} ${l2} l-${l1} ${l2} l-${l2} ${l1} l-${l2} -${l1} l-${l1} -${l2} l${l1} -${l2}'/>`;
            }
        }
    }

    document.getElementById('yolochka').innerHTML = output;
    document.getElementById('yolochkadiv').style.display = 'block';
    setInterval(blink, 80);
}