"use strict";

import { Page } from "../lib/page.js";
import { Ajax } from "../lib/ajax2.js";
import { Popup } from "../lib/popup.js";
import { Editable } from "../lib/editable2.js";
import { EditField } from "../lib/editfield.js";
import { Tooltips } from "../lib/tooltips.js";
import { getParameters } from "../lib/params.js";
const ajax = new Ajax("notes.php");

export class Main {

    static ini() {
        ajax.get({ cmd: 'ini' }).then(_ => {
            const param = getParameters();
            if (param.note) Main.edit(param.note);
            else Main.list();
        });
    }

    static string2words(s) {
        const isLetter = (c) => {
            if (c >= '0' && c <= '9') return true;
            return c.toLowerCase() != c.toUpperCase();
        }
        const result = [];
        let quote = "", word = "";
        for (let c of s) {
            if (isLetter(c)) word += c;
            else {
                if (quote) {
                    if (c != quote) { word += c; continue; }
                    else quote = "";
                } else if (c == '\'' || c == '"') quote = c;

                if (word) { result.push(word); word = ""; }
            }
        }
        if (word) result.push(word);
        return result;
    }

    static list() {
        ajax.get({ cmd: "list" }).then((data) => {

            Page.body.clear().parse(`
                img.logo
                table.list{ tr{
                        td.button{ div.icon.search }
                        td.middle#search
                        td.button{ div.button.icon.plus<tooltip:Create a new note>#new }
                }}`);
            const sniplist = Page.body.insert("table.list");

            const refreshSnippetList = (searchString) => {
                sniplist.clear();
                const words = Main.string2words(searchString.toLowerCase());

                for (const snippet of data.list) {
                    let match = 0;
                    for (const word of words)
                        if (snippet.name.toLowerCase().includes(word)) match++;
                    snippet.match = match;
                }
                data.list.sort((a, b) => 
                    a.match == b.match? (a.time > b.time? -1 : 1) : b.match - a.match);

                let color = 0;
                for (const snippet of data.list) {
                    if (!words.length || snippet.match) {
                        sniplist.parse(`tr{ td.snippet.c${color}#snippet }`);
                        Page.get("snippet").text(snippet.name).element.onclick = _ => {
                            window.location = `?note=${snippet.id}`;
                        };
                        color = 1 - color;
                    }
                }
            }
            refreshSnippetList("");
            
            new EditField(Page.gete("search"), {
                placeholder: "Type in words to search",
                interactive: true,
                focus: true,
                onUpdate: refreshSnippetList
            });
            Page.gete("new").onclick = Main.create;

            new Tooltips();
        });
    }

    static create() {
        ajax.post().then(Main.edit);
    }

    static edit(id) {
        ajax.get({ cmd: "note", id: id }).then((data) => {
            if(data === null) window.location = "?";
            else {
                Page.body.parse(`table.editor{ 
                    tr{ td.button<rowSpan:0> { div.button.icon.left<tooltip:Back to notes list>#back }
                        td{ div.name#name }
                        td.button<rowSpan:0> { div.button.icon.delete<tooltip:Delete this note>#delete }}
                    tr{ td{ div.text#text }}}`);
    
                Page.get("name").text(data.name);
                Page.get("text").html(data.text);
                new EditField(Page.gete("name"), { 
                    placeholder: "Input the name for the note",
                    allowEmpty: false,
                    onUpdate: (value) => {
                        ajax.update({ id: id, name: value }).then();
                        data.name = value;
                    }
                });
                new Editable(Page.gete("text"), {
                    placeholder: "Input the note content",
                    onExit: (value) => {
                        ajax.update({ id: id, text: value }).then();
                    }
                });
                Page.gete("back").onclick = _ => {
                    if (!data.name) new Popup("Please input a name for the note.", [
                        { text: "OK", action: _ => {} }
                    ]); else window.location = "?"; 
                };
                Page.gete("delete").onclick = _ => { Main.delete(data.id); };
                new Tooltips();
    
            }
        });

    }

    static delete(id) {
        new Popup("Do you really want to delete this note?", [
            { text: "Delete", action: _ => {
                ajax.delete({ id: id }).then(_ => { window.location = "?"; });
            }},
            { text: "Cancel", action: _ => {}}
        ])
    }

}
