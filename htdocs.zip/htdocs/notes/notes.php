<?php
header('Content-Type: application/json; charset=utf-8');

$servername = 'localhost';
$username = 'infocat';
$password = 'infoC@T2@24';
$dbname = 'snippets';
$out = [];
$db = NULL;
$time = $_SERVER["REQUEST_TIME"];

ob_start();

try {
    $db = new mysqli($servername, $username, $password, $dbname);
    $out['err'] = FALSE;
    $out['data'] = [];
    $in = $_SERVER["REQUEST_METHOD"] == "GET"? $_GET : json_decode(file_get_contents('php://input'));

    switch ($_SERVER["REQUEST_METHOD"]) {
    case "GET":

        switch ($in['cmd']) {
        case 'ini':
            if ($db->query('SHOW TABLES LIKE "Snippets"')->num_rows == 0) {
                echoln('Snippets table does not exist, creating...');
                $db->query('CREATE TABLE Snippets (
                    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                    name TINYTEXT,
                    text MEDIUMTEXT,
                    time INT UNSIGNED)');
            }
            break;

        case 'list':
            $list = []; $i = 0;
            $q = $db->query('SELECT id, name FROM Snippets ORDER BY time DESC');
            while($s = $q->fetch_assoc()) {
                $list[$i++] = $s;
            }
            $out['data']['list'] = $list;
            break;

        case 'note':
            $q = $db->query('SELECT name, text FROM Snippets WHERE id = '.$in['id']);
            $t = $q->fetch_assoc();
            $out['data'] = $t;
            break;
        }
        break;

    case 'POST':
        $db->query('INSERT INTO Snippets (name, text, time) VALUES ("","","'.$time.'")');
        $q = $db->query('SELECT MAX(id) FROM Snippets');
        $r = $q->fetch_assoc();
        $out['data']['id'] = $r['MAX(id)'];
        break;

    case 'UPDATE':
        $vars = "";
        foreach ($in as $key => $value) {
            if ($key == 'id') continue;
            $vars .= $key.'='.quote($value).',';
        }
        $db->query('UPDATE Snippets SET '.$vars.'time="'.$time.'" WHERE id='.$in->id);
        break;

    case 'DELETE':
        $db->query('DELETE FROM Snippets WHERE id = '.$in->id);
        break;
    }

    $out['log'] = strip_tags(ob_get_clean());
    echo json_encode($out); 
    $db->close();
}

catch(Exception $e) {
    $out['err'] = TRUE;
    $out['log'] = strip_tags(ob_get_clean()).$e->getMessage();
    echo json_encode($out); 
    if ($db) $db->close();
    exit(-1);
}

function echoln($s) {
    echo $s."\r\n";
}
function quote($s) {
    return "'".str_replace("'","''",str_replace("\\", "\\\\",$s))."'";
}

?>