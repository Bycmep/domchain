"use strict";

const Main = {
    ini: () => {
        new DOMchain(document.body).id('body').
            insert("div", { style: "screen" }).
                insert("table").
                    insert("tr").
                        insert("td").
                            insert("img", { style: "logo" }).up().
                        append("td", { style: "document", colSpan: 2 }).id('viewer_window').
                            insert("div", { style: "canvas_stack" }).id('canvas_stack').
                                insert("canvas").id('canvas_0').
                                append("canvas", { style: "disappearing" }).id('canvas_1').up(3).
                    append("tr").
                        insert("td", { style: "panel" }).id('panel').up(3).
            append("div", { style: "overlay" }).id('overlay');

        Panel.ini();
        PDF.ini();
        new Tooltip(DOMchain.gete('overlay'), [ "button", "input" ], 1200);
    }
};

const Panel = {
    ini: () => {
        for (let i = 0; i < 2; i++) {
            DOMchain.get('panel').
                insert("div", { style: "subpanel" }).
                    insert("button", { innerHTML: `Open PDF ${ i + 1 }`, onclick: PDF.open, args: [i], tooltip: "Click to load a PDF file" }).id(`pdf_button_${ i }`).
                    append("br").
                    append("table", { style: "controls" } ).
                        insert("tr", { style: "noshow" } ).id(`pdf_control_${ i }`).
                            insert("td").
                                insert("button", { innerHTML: "◄", onclick: PDF.prev, args: [i], tooltip: "Go to the previous page" }).id(`prev_${ i }`).up().
                            append("td").
                                insert("span", { innerHTML: "Page" } ).
                                    insert("input", { onchange: PDF.goto, args: [i], tooltip: "Enter page number to go to" }).id(`page_${ i }`).up().
                                append("span").id(`of_${ i }`).up().
                            append("td").
                                insert("button", { innerHTML: "►", onclick: PDF.next, args: [i], tooltip: "Go to the next page" }).id(`next_${ i }`);
        }

        DOMchain.get('panel').
            insert("div", { style: [ "subpanel" ] }).
                insert("input", { type: "checkbox", checked: "true", onclick: PDF.link, style: "box", tooltip: "Make both documents open at the same page" }).
                append("span", { innerHTML: "Link pages" });

        DOMchain.get('panel').
            insert("div", { style: [ "subpanel" ] }).
                insert("input", { type: "radio", checked: "checked", onclick: PDF.overlay, name: "mode", tooltip: "Document 2 is output over Document 1, click and hold to see Document 1" }).
                append("span", { innerHTML: "Overlay" }).
                append("br").
                append("input", { type: "radio", onclick: PDF.sidebyside, name: "mode", tooltip: "Document 1 and Document 2 show side by side" }).
                append("span", { innerHTML: "Side by side" }).
                append("br").
                append("input", { type: "radio", onclick: PDF.multiply, name: "mode", tooltip: "Document 1 and Document 2 show as if printed on the same page. Useful for e-forms" }).
                append("span", { innerHTML: "Overprint" });

        DOMchain.get('panel').
        insert("div", { style: [ "subpanel" ] }).
            insert("input", { type: "radio", checked: "checked", onclick: PDF.view, name: "compare", tooltip: "View PDFs as they are" }).
            append("span", { innerHTML: "View" }).
            append("br").
            append("input", { type: "radio", onclick: PDF.highlight, name: "compare", tooltip: "Highlight different pixels" }).
            append("span", { innerHTML: "Highlight" }).
            append("br").
            append("input", { type: "radio", onclick: PDF.fade, name: "compare", tooltip: "Fade identical pixels" }).
            append("span", { innerHTML: "Fade" });

        DOMchain.get('panel').
            insert("div", { style: [ "subpanel", "noshow" ] }).id('zoom_control').
                insert("table", { style: "controls" } ).
                    insert("tr").
                        insert("td").
                            insert("button", { innerHTML: " - ", onclick: PDF.zoom_out, tooltip: "Zoom out" }).id('zoom_out').up().
                        append("td").
                            insert("span", { innerHTML: " Zoom: 100% " } ).id('zoom').up().
                        append("td").
                            insert("button", { innerHTML: " + ", onclick: PDF.zoom_in, tooltip: "Zoom in" }).id('zoom_in').up(3).
                append("div", { innerHTML: "Screen DPI: ", style: "screendpi" }).
                    insert("input", { onchange: PDF.set_screen_dpi, tooltip: "Assumed dot-per-inch ratio of the computer screen. Can be changed to try and achieve 1:1 scale compared to the paper document" }).id('screen_dpi');
    },

    updatePdfControls: () => {
        const min_pages = (PDF.doc[1].pages > 0 && PDF.doc[1].pages < PDF.doc[0].pages) ? PDF.doc[1].pages : PDF.doc[0].pages;
        for (let i = 0; i < 2; i++) {
            if (PDF.doc[i].page > 0) {
                const doc = PDF.doc[i];
                const max_page = (PDF.link_pages) ? min_pages : doc.pages;
                DOMchain.get(`pdf_control_${ i }`).destyle("noshow");
                DOMchain.gete(`prev_${ i }`).disabled = (doc.page < 2);
                DOMchain.gete(`next_${ i }`).disabled = (doc.page >= max_page);
                DOMchain.gete(`page_${ i }`).value = doc.page;
                DOMchain.gete(`of_${ i }`).innerHTML = `of ${ doc.pages }`;
                DOMchain.gete(`pdf_button_${ i }`).tooltip = doc.filename;
            }
        }

        DOMchain.get('zoom_control').destyle("noshow");
        DOMchain.gete('zoom_out').disabled = (PDF.zoom / PDF.zoom_step < 0.3);
        DOMchain.gete('zoom_in').disabled = (PDF.zoom * PDF.zoom_step > 3.1);
        DOMchain.gete('zoom').innerHTML = ` Zoom: ${ Math.round(PDF.zoom * 100) }% `;
    },
};

const PDF = {
    DPI: 300,
    screenDPI: 96,
    zoom: 1,
    zoom_step: 1.201,
    doc: [],
    filename: [],
    pages: [],
    link_pages: true,
    mode: 0,

    ini: () => {
        PDF.load_screen_dpi();
        PDF.canvas = [ DOMchain.gete('canvas_0'), DOMchain.gete('canvas_1') ];
        PDF.ctx = [ PDF.canvas[0].getContext("2d", { alpha: false, willReadFrequently: true }),
            PDF.canvas[1].getContext("2d", { alpha: false, willReadFrequently: true }) ];
        PDF.ctxdata = [];
        PDF.outdata = [];
        PDF.hlite = [];
        for (let i in PDF.canvas) {
            PDF.doc[i] = new Pdf(PDF.canvas[i]);
            PDF.doc[i].DPI = PDF.DPI;
        }
        DOMchain.gete('canvas_stack').style.transform = `scale(${ PDF.zoom * PDF.screenDPI / PDF.DPI })`;
    },

    open: (e) => {
        const n = e.target.args[0];
        PDF.relink = true;
        PDF.doc[n].afterRender = _ => { PDF.afterRender(n); };
        PDF.doc[n].openDialog();
    },

    prev: (e) => {
        const doc_num = e.target.args[0];
        const page = PDF.doc[doc_num].page - 1;
        PDF.go_to(doc_num, page);
    },

    next: (e) => {
        const doc_num = e.target.args[0];
        const page = PDF.doc[doc_num].page + 1;
        PDF.go_to(doc_num, page);
    },

    goto: (e) => {
        e.target.blur();
        const doc_num = e.target.args[0];
        const page = parseInt(e.target.value);
        e.target.value = page;
        if (!isNaN(page)) PDF.go_to(doc_num, page);
        else e.target.value = PDF.doc[doc_num].page;
    },

    go_to: (doc_num, page) => {
        const doc = PDF.doc[doc_num];
        const doc2 = PDF.doc[1 - doc_num];
        const linked = PDF.link_pages && doc2.pages > 0;
        if (page > doc.pages) {
            page = doc.pages;
        }
        if (linked && page > doc2.pages) {
            page = doc2.pages;
        }
        doc.goto(page);
        if (linked) {
            doc2.goto(page);
        }
    },

    afterRender: (n) => {
        if (PDF.relink) {
            PDF.relink = false;
            PDF.link_pages = !PDF.link_pages;
            PDF.link();
        }
        Panel.updatePdfControls();
        PDF.ctxdata[n] = PDF.ctx[n].getImageData(0, 0,
            PDF.ctx[n].canvas.width, PDF.ctx[n].canvas.height);
        PDF.compare(true);
    },

    zoom_in: () => {
        PDF.zum(1);
    },
    
    zoom_out: () => {
        PDF.zum(-1);
    },
    
    zum: (z) => {
        PDF.zoom = (z > 0) ? PDF.zoom * PDF.zoom_step :
            (z < 0) ? PDF.zoom / PDF.zoom_step : PDF.zoom;
        const ratio = PDF.zoom * PDF.screenDPI / PDF.DPI;
        DOMchain.gete('canvas_stack').style.transform = `scale(${ ratio })`;
        Panel.updatePdfControls();
    },

    load_screen_dpi: () => {
        let screenDPI = window.localStorage.getItem('taptest_screendpi');
        if (screenDPI == undefined) screenDPI = PDF.screenDPI;
        else PDF.screenDPI = parseInt(screenDPI);
        DOMchain.gete('screen_dpi').value = screenDPI;
    },

    set_screen_dpi: (e) => {
        let dpi = parseInt(e.target.value);
        e.target.blur();
        if (isNaN(dpi)) dpi = 96;
        else if (dpi < 72) dpi = 72;
        else if (dpi > 400) dpi = 400;
        e.target.value = dpi;
        PDF.screenDPI = dpi;
        window.localStorage.setItem('taptest_screendpi', '' + dpi);
        PDF.zum(0);
    },

    link: () => {
        PDF.link_pages = !PDF.link_pages;
        if (PDF.link_pages) {
            if (PDF.doc[0].page == 0 || PDF.doc[1].page == 0) return;
            if (PDF.doc[0].page > PDF.doc[1].pages) {
                PDF.doc[0].goto(PDF.doc[1].pages);
            }
            if (PDF.doc[1].page > PDF.doc[0].pages) {
                PDF.doc[1].goto(PDF.doc[0].pages);
            }
            PDF.doc[1].goto(PDF.doc[0].page);
        }
    },

    overlay: () => {
        DOMchain.get('canvas_1').destyle('multiply').destyle('sidebyside').style('disappearing');
    },

    multiply: () => {
        DOMchain.get('canvas_1').destyle('disappearing').destyle('sidebyside').style('multiply');
    },

    sidebyside: () => {
        DOMchain.get('canvas_1').destyle('disappearing').destyle('multiply').style('sidebyside');
    },

    view: () => {
        PDF.mode = 0;
        PDF.compare();
    },

    highlight: () => {
        PDF.mode = 1;
        PDF.compare();
    },

    fade: () => {
        PDF.mode = 2;
        PDF.compare();
    },

    compare: (fromRender) => {
        if (PDF.doc[0].rendering || PDF.doc[1].rendering) return;
        if (PDF.mode == 0) {
            if (fromRender) return;
            for (let i = 0; i < 2; i++)
                if(PDF.ctxdata[i])
                    PDF.ctx[i].putImageData(PDF.ctxdata[i], 0, 0);
        }
        else {
            const dx = [], dy = [];
            for (let i = 0; i < 2; i++) {
                dx[i] = PDF.canvas[i].width; dy[i] = PDF.canvas[i].height;
            }
            const dxmin = dx[0] < dx[1]? dx[0] : dx[1];
            const dymin = dy[0] < dy[1]? dy[0] : dy[1];
            if (!dxmin || !dymin) return;
            const get = (n, x, y, color) => {
                return PDF.ctxdata[n].data[(y*dx[n] + x)*4 + color];
            }

            if (PDF.mode == 1) {
                const hlite = new Array(dxmin*dymin);
                hlite.fill(false);
                const threshold = 0, highlight = [255, 255, 0], r = 4;
                for (let y = 0; y < dymin; y++)
                    for (let x = 0; x < dxmin; x++) {
                        const dr = get(0, x, y, 0) - get(1, x, y, 0);
                        const dg = get(0, x, y, 1) - get(1, x, y, 1);
                        const db = get(0, x, y, 2) - get(1, x, y, 2);
                        if (dr*dr + dg*dg + db*db > threshold) {
                            for (let y1 = (y<r? 0 : y-r); y1 <= (y+r>dymin-1? dymin-1 : y+r); y1++) {
                                for (let x1 = (x<r? 0 : x-r); x1 <= (x+r>dxmin-1? dxmin-1 : x+r); x1++) {
                                    hlite[y1*dxmin + x1] = true;
                                }
                            }
                        }
                }
                for (let i = 0; i < 2; i++) {
                    const outdata = structuredClone(PDF.ctxdata[i]);
                    let p1 = 0, p2 = 0;
                    for (let y = 0; y < dymin; y++)
                        for (let x = 0; x < dxmin; x++) {
                            if (hlite[p1]) {
                                outdata.data[p2] =
                                    (PDF.ctxdata[i].data[p2]*highlight[0])>>8;
                                outdata.data[p2+1] =
                                    (PDF.ctxdata[i].data[p2+1]*highlight[1])>>8;
                                outdata.data[p2+2] =
                                    (PDF.ctxdata[i].data[p2+2]*highlight[2])>>8;
                            } 
                            p1 ++; p2 += 4;
                    }
                    PDF.ctx[i].putImageData(outdata, 0, 0);
                }
            } else {
                const threshold = 0, g = 220;
                const outdata0 = structuredClone(PDF.ctxdata[0]);
                const outdata1 = structuredClone(PDF.ctxdata[1]);

                for (let y = 0; y < dymin; y++)
                    for (let x = 0; x < dxmin; x++) {
                        const p0 = (y*dx[0] + x)*4, p1 = (y*dx[1] + x)*4;
                        const dr = PDF.ctxdata[0].data[p0] - PDF.ctxdata[1].data[p1];
                        const dg = PDF.ctxdata[0].data[p0+1] - PDF.ctxdata[1].data[p1+1];
                        const db = PDF.ctxdata[0].data[p0+2] - PDF.ctxdata[1].data[p1+2];
                        if (dr*dr + dg*dg + db*db <= threshold) {
                            if (outdata0.data[p0] < g) outdata0.data[p0] = g;
                            if (outdata0.data[p0+1] < g) outdata0.data[p0+1] = g;
                            if (outdata0.data[p0+2] < g) outdata0.data[p0+2] = g;
                            if (outdata1.data[p1] < g) outdata1.data[p1] = g;
                            if (outdata1.data[p1+1] < g) outdata1.data[p1+1] = g;
                            if (outdata1.data[p1+2] < g) outdata1.data[p1+2] = g;
                        }
                }
                PDF.ctx[0].putImageData(outdata0, 0, 0);
                PDF.ctx[1].putImageData(outdata1, 0, 0);
            }
        }
    },


    hideidentical: () => {
        PDF.hide = !PDF.hide;
        const dx = [], dy = [];
        if (PDF.hide) {
            for (let i = 0; i < 2; i++) {
                dx[i] = PDF.canvas[i].width; dy[i] = PDF.canvas[i].height;
            }
            const dxmin = dx[0] < dx[1]? dx[0] : dx[1];
            const dymin = dy[0] < dy[1]? dy[0] : dy[1];
            if (!dxmin || !dymin) return;
            for (let i = 0; i < 2; i++) {
                PDF.ctxdata[i] = PDF.ctx[i].getImageData(0, 0, dxmin, dymin);
                PDF.outdata[i] = PDF.ctx[i].getImageData(0, 0, dxmin, dymin);
            }
            PDF.hlite = new Uint8Array(dxmin*dymin);
            PDF.hlite.fill(0);
            let p = 0;
            const threshold = 0, g = 220, highlight = [255, 255, 0], r = 8;
            for (let y = 0; y < dymin; y++)
                for (let x = 0; x < dxmin; x++) {
                    const dr = PDF.ctxdata[0].data[p] - PDF.ctxdata[1].data[p];
                    const dg = PDF.ctxdata[0].data[p + 1] - PDF.ctxdata[1].data[p + 1];
                    const db = PDF.ctxdata[0].data[p + 2] - PDF.ctxdata[1].data[p + 2];
                    if (dr*dr + dg*dg + db*db <= threshold) {
/*                        if (PDF.outdata[0].data[p] < g) PDF.outdata[0].data[p] = g;
                        if (PDF.outdata[1].data[p] < g) PDF.outdata[1].data[p] = g;
                        if (PDF.outdata[0].data[p + 1] < g) PDF.outdata[0].data[p + 1] = g;
                        if (PDF.outdata[1].data[p + 1] < g) PDF.outdata[1].data[p + 1] = g;
                        if (PDF.outdata[0].data[p + 2] < g) PDF.outdata[0].data[p + 2] = g;
                        if (PDF.outdata[1].data[p + 2] < g) PDF.outdata[1].data[p + 2] = g; */
                    } else {
                        for (let y1 = (y<r? 0 : y-r); y1 <= (y+r>dymin-1? dymin-1 : y+r); y1++) {
                            for (let x1 = (x<r? 0 : x-r); x1 <= (x+r>dxmin-1? dxmin-1 : x+r); x1++) {
                                PDF.hlite[y1*dxmin + x1] = 1;
                            }
                        }
                    }
                    p += 4;
            }
            p = 0;
            for (let y = 0; y < dymin; y++)
                for (let x = 0; x < dxmin; x++) {
                    if (PDF.hlite[p]) {
                        PDF.outdata[0].data[p*4] =
                            Math.round(PDF.outdata[0].data[p*4]*highlight[0]/255);
                        PDF.outdata[0].data[p*4+1] =
                            Math.round(PDF.outdata[0].data[p*4+1]*highlight[1]/255);
                        PDF.outdata[0].data[p*4+2] =
                            Math.round(PDF.outdata[0].data[p*4+2]**highlight[2]/255);
                    }
                    p++;
            }
            for (let i = 0; i < 2; i++) {
                PDF.ctx[i].putImageData(PDF.outdata[i], 0, 0);
            }
//            PDF.ctx[0].putImageData(PDF.hlite, 0, 0);

        }
    }
};

