"use strict";

class DOMchain { // v1
    static ids = [];

    constructor(element, parent) {
        this.element = element;
        this.parent = parent;
    }

    insert(type, parameters) {
        let e = document.createElement(type);
        this.element.appendChild(e);
        if (parameters != undefined) {
            for (const property in parameters) {
                const value = parameters[property];
                switch (property) {
                    case 'style': 
                        if (typeof(value) == 'string') e.classList.add(value);
                        else for (const style of value) {
                            e.classList.add(style);
                        } break;
                    default: e[property] = value;
                }
            }
        }
        const created = new DOMchain(e, this);
        if (this.child == undefined) this.child = [ created ];
        else this.child.push(created);
        return created;
    }

    append(type, param) {
        return this.parent.insert(type, param);
    }

    up(n) {
        let r = this;
        if (n == undefined) n = 1;
        for (let i = 0; i < n; i++) r = r.parent;
        return r;
    }

    style(style) {
        this.element.classList.add(style);
        return this;
    }

    destyle(style) {
        this.element.classList.remove(style);
        return this;
    }

    id(id) {
        DOMchain.ids[id] = this;
        return this;
    }

    static get(id) {
        return DOMchain.ids[id];
    }

    static gete(id) {
        return DOMchain.ids[id].element;
    }

    clear() {
        this.element.innerHTML = "";
        this.child = undefined;
        return this;
    }

    remove() {
        this.element.remove();
        if (this.parent != undefined) {
            const index = this.parent.child.indexOf(this);
            if(index != -1) {
                this.parent.child.splice(index, 1);
            }
        }
    }
}

class Pdf { // v1
    constructor(canvas) {
        this.pdfjsLib = window['pdfjs-dist/build/pdf'];
        this.pdfjsLib.GlobalWorkerOptions.workerSrc = './pdf.worker.js';
        this.canvas = canvas;
        this.DPI = 300;
        this.afterRender = () => {};
        this.context = canvas.getContext('2d');
        this.rendering = false;
        this.pending = 0;
        this.page = 0;
        this.pages = 0;
        this.canvas.height = 0;
        this.canvas.width = 0;
    }

    open(file) {
        this.filename = file.name;
        if (this.page == 0) this.page = 1;
        const obj = this;

        this.pdfjsLib.getDocument(
            URL.createObjectURL(file)).promise.then(function(pdf_doc) {
                obj.doc = pdf_doc;
                obj.pages = obj.doc.numPages;
                if (obj.page > obj.pages) obj.page = obj.pages;
                obj.render(obj.page);
            }
        );
    }

    openDialog() {
        let input = document.createElement('input');
        input.type = 'file'; input.accept = '.pdf';
        input.onchange = _ => {
            this.open(input.files[0]);
            input.remove();
        };
        input.click();
    }

    render(pageNum) {
        this.rendering = true;
        const obj = this;
    
        this.doc.getPage(pageNum).then(function(page) {
            const viewport = page.getViewport({scale: obj.DPI / 72});
            obj.canvas.height = viewport.height;
            obj.canvas.width = viewport.width;
            
            let renderTask = page.render({ canvasContext: obj.context, viewport: viewport });
    
            renderTask.promise.then(function() {
                obj.rendering = false;
                obj.page = pageNum;
                obj.afterRender();
                if (obj.pending != 0) {
                    obj.render(obj.pending);
                    obj.pending = 0;
                }
            });
        });
    }

    goto(pageNum) {
        if (pageNum < 1) pageNum = 1;
        if (pageNum > this.pages) pageNum = this.pages;
        if (pageNum == this.page) return;
        
        if (this.rendering) {
            this.pending = pageNum;
            } else {
            this.render(pageNum);
        }
    }

}

class Tooltip { //v1
    tooltip = null;
    elems = null;
    timeout = null;

    constructor(overlay, tags, delay) {
        this.overlay = overlay;
        this.tags = tags;
        this.delay = (delay == undefined) ? 0 : delay;
        this.refresh();
    }

    refresh() {
        this.remove();
        let elems = [];
        function toArray(input) {
            const output = [];
            for (const i of input) output.push(i);
            return output;
        }
        if (typeof(this.tags) == 'string') elems = toArray(document.getElementsByTagName(this.tags));
        else for (const tag of this.tags) {
            elems = elems.concat(toArray(document.getElementsByTagName(tag)));
        }
        this.elems = [];
        for (const e of elems) {
            if (e.tooltip != undefined) this.elems.push(e);
        }
        for (const elem of this.elems) {
            elem.ttip = { mouseover: elem.onmouseover, mouseout: elem.onmouseout };
            elem.onmouseover = e => {
                if (this.timeout != null) clearTimeout(this.timeout);
                this.timeout = setTimeout((target, x, y) => {
                    if (target.tooltip != undefined && target.tooltip != "") {
                        if (this.tooltip == null) {
                            this.tooltip = document.createElement("div");
                            this.overlay.appendChild(this.tooltip);
                            this.tooltip.classList.add("tooltip");
                        }
                        this.tooltip.innerHTML = target.tooltip;
                        this.tooltip.style.left = `${ x - this.tooltip.clientWidth * x / document.body.clientWidth }px`;
                        this.tooltip.style.top = `${ y }px`;
                    }
                    this.timeout = null;
                }, this.delay, e.target, e.pageX, e.pageY);
                e.target.ttip.mouseover;
            };

            elem.onmouseout = e => {
                if (this.timeout != null) clearTimeout(this.timeout);
                if (this.tooltip != null) {
                    this.tooltip.remove();
                    this.tooltip = null;
                }
                e.target.ttip.mouseout;
            };
        }
    }

    remove() {
        if (this.tooltip != null) this.tooltip.remove();
        if (this.elems != null)
            for (const elem of this.elems) {
                elem.onmouseover = elem.ttip.mouseover;
                elem.onmouseout = elem.ttip.mouseoot;
            }
    }

}
