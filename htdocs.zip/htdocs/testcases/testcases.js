"use strict";

import { Page } from "../lib/page.js";
import { Ajax } from "../lib/ajax1.js";
import { Popup } from "../lib/popup.js";
import { Editable } from "../lib/editable2.js";
import { EditField } from "../lib/editfield.js";
import { Tooltips } from "../lib/tooltips.js";
import { getWords } from "../lib/getwords.js";

const ajax = new Ajax("testcases.php");

export class Main {
    static dict = [];

    static ini() {
        ajax.get({ ap: 'ini' }, _ => { Main.getDict(0); });
    }

    static getDict(n) {
        const dicts = [ "project", "application", "category", "priority", "environment" ];
        if (n >= dicts.length) Main.list();
        else ajax.get({ ap: 'dictionary', name: dicts[n] }, (data) => {
            Main.dict[dicts[n]] = data;
            Main.getDict(n + 1);
        });
    }

    static list() {
        let list;
        Page.body.clear().parse(`
            img.logo
            table.tclisthead{ tr{
                    td.button{ div.icon.search }
                    td.field#search
                    td.button{ div.button.icon.plus<tooltip:Create a new test case>#new }
            }}
            table.tclist {
                thead{ tr{ td(Project)#pjoject td(Application)#application
                    td(Priority)#priority td(Category)#category
                    td(ID)#id td(Name)#name td(Time)#time td(Environment)#environment }}
                tbody#tclist }`);
        
        const outputTClist = (searchString) => {
            const table = Page.get("tclist").clear();
            const words = getWords(searchString.toLowerCase());

            for (const tcase of list) {
                let match = 0;
                for (const word of words)
                    if (tcase.name.toLowerCase().includes(word)) match++;
                tcase.match = match;
            }
            list.sort((a, b) => a.match == b.match? (a.caseid > b.caseid? 1 : -1) : b.match - a.match);

            let row = 0;
            for (const tccase of list) {
                if (!words.length || tccase.match) {
                    table.insert("tr").class(`color${row}`).
                            set({onclick: _ => { Main.edit(tccase.id); }, tooltip: "Click to edit" }).
                        insert("td").text(tccase.project).
                        append("td").text(tccase.application).
                        append("td").text(tccase.priority).
                        append("td").text(tccase.category).
                        append("td").text(tccase.caseid).
                        append("td").text(tccase.name).
                        append("td").html(`${tccase.time}&nbsp;min`).class('number').
                        append("td").text(tccase.environment);
                    row = 1 - row;
                }
            }
            new Tooltips();
        }
        ajax.get({ ap: "allcases" }, (data) => { list = data; outputTClist("") });

        Page.gete("new").onclick = Main.create;
        new EditField(Page.gete("search"), {
            placeholder: "Type in name to search",
            interactive: true,
            onUpdate: outputTClist
        });

    }

    static create() {
        ajax.post({ ap: 'case' }, Main.edit);
    }

    static edit(id) {
        ajax.get({ ap: 'case', id: id }, (data) => { 
            Main.editor(id, data[0]); });
    }

    static editor(id, data) {
        Page.body.clear().parse(`table.tcheader{ 
            tr{ td.button<rowSpan:0> { div.button.icon.left<tooltip:Back to test cases list>#back }
                td.name.bold(Test case name:) td.field#name
                td.button<rowSpan:0> { div.button.icon.copy<tooltip:Clone this test case>#clone
                    div.button.icon.delete<tooltip:Delete this test case>#delete }}
            tr{ td.name(ID:) td.field#caseid }
            tr{ td.name(Project:) td.field#project }
            tr{ td.name(Application:) td.field#application }
            tr{ td.name(Category:) td.field#category }
            tr{ td.name(Priority:) td.field#priority }
            tr{ td.name("Run time (min):") td.field#time }
            tr{ td.name(Environment:) td.field#environment }}
        table.tcbody{
            tr{ td.name<colSpan:2>(Preconditions:) }
            tr{ td.field<colSpan:2>#preconditions }
            tr{ td.name(Steps:) td.name(Expected results:) }
            tr{ td.field#steps td.field#results }}`);

        const fields = [ "name", "caseid", "time" ];
        for (const field of fields) {
            const input = Page.get(field);
            if(data[field] != undefined) input.text(data[field]);
            new EditField(input.element, {
                number: field == "time",
                onUpdate: (value) => {
                    const updata = { ap: 'case', id: id };
                    updata[field] = value;
                    ajax.update(updata);
                }
            }); 
        }

        const dicts = [ "project", "application", "category", "priority", "environment" ];
        for (const field of dicts) {
            ajax.get({ ap: 'dictionary', name: field }, (dictdata) => {
                const input = Page.get(field);
                if(data[field] != undefined) input.text(data[field]);
                new EditField(input.element, {
                    dictionary: { data: dictdata, class: 'dict' },
                    onUpdate: (value) => {
                        const updata = { ap: 'case', id: id };
                        updata[field] = value;
                        ajax.update(updata);
                    }
                }); 
            });
        }

        const texts = [ "preconditions", "steps", "results" ];
        for (const text of texts) {
            const input = Page.get(text);
            if(data[text] != undefined) input.html(data[text]);
            new Editable(input.element, {
                placeholder: '|',
                onExit: (value) => {
                    const updata = { ap: 'case', id: id };
                    updata[text] = value;
                    ajax.update(updata);
                }
            }); 
        }

        Page.gete("back").onclick = Main.list;
        Page.gete("clone").onclick = _ => {
            ajax.post({ ap:'caseclone', id: id }, Main.edit);
        };
        Page.gete("delete").onclick = _ => {
            new Popup("Do you really want to delete this test case?", [
                { text: "Delete", action: _ => {
                    ajax.delete({ ap: 'case', id: id }, Main.list);
                }},
                { text: "Cancel", action: _ => {}}
            ]); };
        new Tooltips();

    }
}
