<?php
header('Content-Type: application/json; charset=utf-8');

$servername = 'localhost';
$username = 'infocat';
$password = 'infoC@T2@24';
$dbname = 'infocat';
$out = [];
$db = NULL;
$time = $_SERVER["REQUEST_TIME"];
$debug = FALSE;
$dictionaries = [ "project", "application", "category", "priority", "environment" ];

ob_start();

try {
    $db = new mysqli($servername, $username, $password, $dbname);
    $out['err'] = FALSE;
    $in = $_SERVER["REQUEST_METHOD"] == "GET"?
        (object)$_GET : json_decode(file_get_contents('php://input'));
    if ($debug) var_dump($in);
    
    $fun = $in->ap.$_SERVER["REQUEST_METHOD"];
    unset($in->ap);
    $out['data'] = $fun($in);

    if ($debug) var_dump($out['data']);
    $out['log'] = strip_tags(ob_get_clean());
    echo json_encode($out); 
    $db->close();
}

catch(Exception $e) {
    $out['err'] = TRUE;
    $out['log'] = strip_tags(ob_get_clean()).$e->getMessage();
    echo json_encode($out); 
    if ($db) $db->close();
    exit(-1);
}

#####################

function iniGET() {
    global $dictionaries;

    if (dbcount('SHOW TABLES LIKE "testcase"') == 0) {
        echoln('Creating testcase table.');
        dbrun('CREATE TABLE testcase (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            projectid INT UNSIGNED,
            applicationid INT UNSIGNED,
            caseid TINYTEXT,
            name TINYTEXT,
            categoryid INT UNSIGNED,
            priorityid INT UNSIGNED,
            time INT UNSIGNED,
            environmentid INT UNSIGNED,
            preconditions MEDIUMTEXT,
            steps MEDIUMTEXT,
            results MEDIUMTEXT)');
    }
    foreach ($dictionaries as $dict) {
        if (dbcount('SHOW TABLES LIKE "'.$dict.'"') == 0) {
            echoln('Creating '.$dict.' table.');
            dbrun('CREATE TABLE '.$dict.'(id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, '.
                $dict.' TINYTEXT, num INT UNSIGNED)');
        }
    }
}

function allcasesGET() {
    return dbfetch('SELECT testcase.id as id, project, application, caseid, name,
        category, priority, time, environment FROM testcase
        LEFT JOIN project ON testcase.projectid = project.id
        LEFT JOIN application ON testcase.applicationid = application.id
        LEFT JOIN category ON testcase.categoryid = category.id
        LEFT JOIN priority ON testcase.priorityid = priority.id
        LEFT JOIN environment ON testcase.environmentid = environment.id ORDER BY caseid');
}

function caseGET($arg) {
    return dbfetch('SELECT project, application, caseid, name, category,
        priority, time, environment, preconditions, steps, results FROM testcase
        LEFT JOIN project ON testcase.projectid = project.id
        LEFT JOIN application ON testcase.applicationid = application.id
        LEFT JOIN category ON testcase.categoryid = category.id
        LEFT JOIN priority ON testcase.priorityid = priority.id
        LEFT JOIN environment ON testcase.environmentid = environment.id
        WHERE testcase.id = '.$arg->id);
}

function casePOST($arg) {
    global $dictionaries;

    $names = ""; $values = "";
    foreach ($arg as $key => $value) {
        if (in_array($key, $dictionaries)) {
            $value = checkDictionaries($key, $value);
            $key .= 'id';
        }
        if ($names != "") { $names .= ', '; $values .= ', '; }
        $names .= $key; $values .= quote($value);
    }

    dbrun('INSERT INTO testcase ('.$names.') VALUES ('.$values.')');
    return dbfetch('SELECT LAST_INSERT_ID()')[0];
}

function caseUPDATE($arg) {
    global $dictionaries;

    $set = "";
    foreach ($arg as $key => $value) {
        if ($key == 'id') continue;
        if (in_array($key, $dictionaries)) {
            $value = checkDictionaries($key, $value);
            $key .= 'id';
        }
        if ($set != "") $set .= ', ';
        $set .= $key.' = '.quote($value);
    }

    dbrun('UPDATE testcase SET '.$set.' WHERE id = '.$arg->id);
    return $arg->id;
}

function caseDELETE($arg) {
    dbrun('DELETE FROM testcase WHERE id = '.$arg->id);
}

function checkDictionaries($key, $value) {
    if ($value == "") return "";
    $index = dbfetch('SELECT id FROM '.$key.' WHERE '.$key.' = '.quote($value));
    if (count($index) != 0) return $index[0];

    $num = dbfetch('SELECT MAX(num) FROM '.$key);
    $num = (count($num) == 0)? 1 : (int)$num[0] + 1;
    dbrun('INSERT INTO '.$key.' ('.$key.', num) VALUES ('.quote($value).', '.$num.')');
    return dbfetch('SELECT LAST_INSERT_ID()')[0];
}

function dictionaryGET($arg) {
    global $dictionaries;
    if (!in_array($arg->name, $dictionaries)) return;
    return dbfetch('SELECT '.$arg->name.' FROM '.$arg->name.' ORDER BY num');
}

function caseclonePOST($arg) {
    $case = dbfetch('SELECT projectid, applicationid, caseid, name, categoryid,
        priorityid, time, environmentid, preconditions, steps, results FROM testcase
        WHERE testcase.id = '.$arg->id)[0];
    $case['name'] = 'Clone of '.$case['name'];

    $names = ""; $values = "";
    foreach ($case as $key => $value) {
        if ($names != "") { $names .= ', '; $values .= ', '; }
        $names .= $key; $values .= quote($value);
    }

    dbrun('INSERT INTO testcase ('.$names.') VALUES ('.$values.')');
    return dbfetch('SELECT LAST_INSERT_ID()')[0];
}

####################

function dbrun($sql) {
    global $db, $debug;
    if ($debug) echoln($sql);
    $db->query($sql);
}
function dbcount($sql) {
    global $db, $debug;
    if ($debug) echoln($sql);
    return $db->query($sql)->num_rows;
}
function dbfetch($sql) {
    global $db, $debug;
    if ($debug) echoln($sql);
    $q = $db->query($sql);
    $list = []; $i = 0;
    while ($s = $q->fetch_assoc()) {
        if (count($s) < 2) $s = reset($s);
        $list[$i++] = $s;
    }
    return $list;
}

function echoln($s) {
    echo $s."\r\n";
}
function quote($s) {
    if ($s == "") return "NULL"; 
    return "'".str_replace("'","''",$s)."'";
}

?>