<?php
header('Content-Type: application/json; charset=utf-8');

$servername = 'localhost';
$username = 'infocat';
$password = 'infoC@T2@24';
$dbname = 'infocat';
$out = [];
$db = NULL;
$time = $_SERVER["REQUEST_TIME"];
$dicts = [ "project", "application", "category", "priority", "environment" ];

ob_start();

try {
    $db = new mysqli($servername, $username, $password, $dbname);
    $out['err'] = FALSE;
    $in = $_SERVER["REQUEST_METHOD"] == "GET"?
        (object)$_GET : json_decode(file_get_contents('php://input'));

    var_dump($in);
    switch ($_SERVER["REQUEST_METHOD"]) {
    case "GET":

        switch ($in['obj']) {
        case 'ini':
            if ($db->query('SHOW TABLES LIKE "testcase"')->num_rows == 0) {
                echoln('Creating testcase table.');
                $db->query('CREATE TABLE testcase (
                    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                    projectid INT UNSIGNED,
                    applicationid INT UNSIGNED,
                    caseid TINYTEXT,
                    name TINYTEXT,
                    categoryid INT UNSIGNED,
                    priorityid INT UNSIGNED,
                    time INT UNSIGNED,
                    environmentid INT UNSIGNED,
                    preconditions MEDIUMTEXT,
                    steps MEDIUMTEXT,
                    results MEDIUMTEXT)');
            }
            foreach ($dicts as $dict) {
                if ($db->query('SHOW TABLES LIKE "'.$dict.'"')->num_rows == 0) {
                    echoln('Creating '.$dict.' table.');
                    $db->query('CREATE TABLE '.$dict.'('.
                        $dict.'id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, '.
                        $dict.' TINYTEXT, num INT UNSIGNED)');
                }
            }
            break;

            case 'allcases':
                $list = []; $i = 0;
                $q = $db->query('SELECT id, project, application, sysid, name, category, priority,
                    time, environment FROM testcase
                    LEFT JOIN project ON projectid LEFT JOIN application ON applicationid
                    LEFT JOIN category ON categoryid LEFT JOIN priority ON priorityid
                    LEFT JOIN environment ON environmentid');
                while($s = $q->fetch_assoc()) {
                    $list[$i++] = $s;
                }
                $out['list'] = $list;
            break;
    
            case 'case':
                $list = []; $i = 0;
                $q = $db->query('SELECT preconditions, steps, results
                    FROM testcase WHERE id = '.$in['id']);
                while($s = $q->fetch_assoc()) {
                    $list[$i++] = $s;
                }
                $out['list'] = $list;
            break;

            case 'dictionary':
                $list = []; $i = 0; $dict = $in['name'];
                if (in_array($dict, $dicts)) {
                    $q = $db->query('SELECT '.$dict.'id as value FROM '.$dict.' ORDER BY num');
                    while($s = $q->fetch_assoc()) {
                        $list[$i++] = $s['value'];
                    }
                }
                $out['list'] = $list;
            break;
        }
        break;

    case 'POST':

        $names = ""; $values = "";
        foreach ($in as $key => $value) {
            if ($key == 'obj') continue;
            if (in_array($key, $dicts)) {
                $q = $db->query('SELECT '.$key.'id as value FROM '.$key.' WHERE '.$key.'='.$value);
                if ($q->num_rows) {
                    $r = $q->fetch_assoc();
                    $value = $r['value'];
                } else {
                    $value = addToDict($key, $value);
                }
            } 
            if ($names != "") { $names .= ','; $values .= ','; }
            $names .= $key; $values .= quote($value);
        }

        $db->query('INSERT INTO '.$in->obj.' ('.$names.') VALUES ('.$values.')');
        $q = $db->query('SELECT MAX(id) FROM '.$in->obj);
        $r = $q->fetch_assoc();
        $out['id'] = $r['MAX(id)'];
        break;

    case 'UPDATE':
        $vars = "";
        foreach ($in as $key => $value) {
            if ($key == 'id' || $key == 'obj') continue;
            if ($vars != "") $vars .= ',';
            $vars .= $key.'='.quote($value);
        }
        echoln('UPDATE '.$in->obj.' SET '.$vars.' WHERE id='.$in->id);
        $db->query('UPDATE '.$in->obj.' SET '.$vars.' WHERE id='.$in->id);
        break;

    case 'DELETE':
        $db->query('DELETE FROM '.$in->obj.' WHERE id='.$in->id);
        break;
    }

    $out['log'] = strip_tags(ob_get_clean());
    echo json_encode($out); 
    $db->close();
}

catch(Exception $e) {
    $out['err'] = TRUE;
    $out['log'] = strip_tags(ob_get_clean()).$e->getMessage();
    echo json_encode($out); 
    if ($db) $db->close();
    exit(-1);
}

function addToDict($dict, $value) {
    $num = ($db->query('SELECT MAX(num) FROM '.$dict)->fetch_assoc())['MAX(num)'];
    $num = ($num == NULL)? 1 : (int)$num + 1;
    $db->query('INSERT INTO '.$dict.' ('.$dict.'id, num) VALUES ('.$value.', '.$num.')');
    return ($db->query('SELECT MAX(id) FROM '.$dict)->fetch_assoc())['MAX(id)'];
}

function echoln($s) {
    echo $s."\r\n";
}
function quote($s) {
    if ($s == NULL) return 'NULL'; 
    return "'".str_replace("'","''",$s)."'";
}

?>